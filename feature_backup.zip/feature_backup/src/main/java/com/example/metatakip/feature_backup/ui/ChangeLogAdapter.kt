package com.example.metatakip.feature_backup.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.metatakip.feature_backup.R
import com.example.metatakip.feature_backup.data.ChangeLog

class ChangeLogAdapter : RecyclerView.Adapter<ChangeLogAdapter.ViewHolder>() {

    private var changes: List<ChangeLog> = emptyList()

    fun submitList(newChanges: List<ChangeLog>) {
        changes = newChanges
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_1, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val change = changes[position]
        holder.textView.text = change.getDisplayMessage()

        // Arka plan rengi
        holder.itemView.setBackgroundColor(
            when (change.actionType) {
                ChangeLog.ActionType.INSERT -> 0x20_00FF00
                ChangeLog.ActionType.UPDATE -> 0x20_FFA500
                ChangeLog.ActionType.DELETE -> 0x20_FF0000
            }
        )
    }

    override fun getItemCount(): Int = changes.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textView: TextView = itemView.findViewById(android.R.id.text1)
    }
}