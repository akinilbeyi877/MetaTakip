package com.example.metatakip.feature_backup.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object TimeUtils {
    fun timestamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
    fun todayFolder(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    fun formatTime(millis: Long): String = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(millis))
}