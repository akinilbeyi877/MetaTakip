package com.example.metatakip.feature_backup.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.metatakip.feature_backup.R
import com.example.metatakip.feature_backup.data.ChangeLog
import com.example.metatakip.feature_backup.util.ChangeLogManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LiveChangesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var tvLastUpdate: TextView
    private lateinit var tvStats: TextView
    private lateinit var btnRefresh: Button
    private lateinit var btnClear: Button

    private lateinit var adapter: ChangeLogAdapter
    private val handler = Handler(Looper.getMainLooper())
    private var refreshRunnable: Runnable? = null

    private val changeListener = object : ChangeLogManager.OnChangeListener {
        override fun onNewChange(change: ChangeLog) {
            runOnUiThread {
                adapter.addChange(change)
                updateStats()
                scrollToTop()

                // Son güncelleme zamanını göster
                tvLastUpdate.text = "Son güncelleme: ${formatTime(System.currentTimeMillis())}"
            }
        }

        override fun onChangesUpdated(changes: List<ChangeLog>) {
            runOnUiThread {
                adapter.updateChanges(changes)
                updateStats()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_live_changes)

        initViews()
        setupRecyclerView()
        setupListeners()
        startAutoRefresh()

        // ChangeLogManager'a dinleyici ekle
        ChangeLogManager.addListener(changeListener)

        // Mevcut değişiklikleri yükle
        loadInitialChanges()
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerView)
        tvLastUpdate = findViewById(R.id.tvLastUpdate)
        tvStats = findViewById(R.id.tvStats)
        btnRefresh = findViewById(R.id.btnRefresh)
        btnClear = findViewById(R.id.btnClear)

        tvLastUpdate.text = "Son güncelleme: ${formatTime(System.currentTimeMillis())}"
    }

    private fun setupRecyclerView() {
        adapter = ChangeLogAdapter()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun setupListeners() {
        btnRefresh.setOnClickListener {
            refreshChanges()
        }

        btnClear.setOnClickListener {
            clearAllChanges()
        }

        findViewById<Button>(R.id.btnBack).setOnClickListener {
            finish()
        }
    }

    private fun loadInitialChanges() {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                ChangeLogManager.refreshRecentChanges(this@LiveChangesActivity)
            }
        }
    }

    private fun refreshChanges() {
        btnRefresh.isEnabled = false
        btnRefresh.text = "Yenileniyor..."

        lifecycleScope.launch {
            val newChanges = withContext(Dispatchers.IO) {
                ChangeLogManager.checkForNewChanges(this@LiveChangesActivity)
            }

            withContext(Dispatchers.Main) {
                btnRefresh.isEnabled = true
                btnRefresh.text = "🔄 Yenile"

                if (newChanges.isNotEmpty()) {
                    tvLastUpdate.text = "Son güncelleme: ${formatTime(System.currentTimeMillis())}"
                }
            }
        }
    }

    private fun clearAllChanges() {
        // Sadece ekrandaki listeyi temizle, veritabanındakileri değil
        adapter.clear()
        tvStats.text = "Toplam: 0 değişiklik"
    }

    private fun startAutoRefresh() {
        // Her 5 saniyede bir otomatik yenile
        refreshRunnable = object : Runnable {
            override fun run() {
                if (!isFinishing) {
                    refreshChanges()
                    handler.postDelayed(this, 5000)
                }
            }
        }
        handler.postDelayed(refreshRunnable!!, 5000)
    }

    private fun updateStats() {
        val total = adapter.itemCount
        val insert = adapter.getCountByType(ChangeLog.ActionType.INSERT)
        val update = adapter.getCountByType(ChangeLog.ActionType.UPDATE)
        val delete = adapter.getCountByType(ChangeLog.ActionType.DELETE)

        tvStats.text = "Toplam: $total  |  🟢 Ekleme: $insert  |  🔄 Güncelleme: $update  |  🔴 Silme: $delete"
    }

    private fun scrollToTop() {
        recyclerView.scrollToPosition(0)
    }

    private fun formatTime(timestamp: Long): String {
        return SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
    }

    override fun onDestroy() {
        super.onDestroy()
        refreshRunnable?.let { handler.removeCallbacks(it) }
        ChangeLogManager.removeListener(changeListener)
    }

    // ================== ADAPTER ==================

    class ChangeLogAdapter : RecyclerView.Adapter<ChangeLogAdapter.ViewHolder>() {

        private val changes = mutableListOf<ChangeLog>()

        fun addChange(change: ChangeLog) {
            changes.add(0, change)
            notifyItemInserted(0)

            // Listeyi çok uzatmamak için 100 kayıt tut
            if (changes.size > 100) {
                changes.removeAt(changes.lastIndex)
                notifyItemRemoved(changes.size)
            }
        }

        fun updateChanges(newChanges: List<ChangeLog>) {
            changes.clear()
            changes.addAll(newChanges)
            notifyDataSetChanged()
        }

        fun clear() {
            changes.clear()
            notifyDataSetChanged()
        }

        fun getCountByType(type: ChangeLog.ActionType): Int {
            return changes.count { it.actionType == type }
        }

        override fun getItemCount(): Int = changes.size

        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
            val view = android.view.LayoutInflater.from(parent.context)
                .inflate(android.R.layout.simple_list_item_2, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val change = changes[position]

            val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                .format(Date(change.changedAt))

            val icon = when (change.actionType) {
                ChangeLog.ActionType.INSERT -> "🟢"
                ChangeLog.ActionType.UPDATE -> "🔄"
                ChangeLog.ActionType.DELETE -> "🔴"
            }

            val tableNameTr = when (change.tableName) {
                "musteri" -> "Müşteri"
                "siparis" -> "Sipariş"
                "firma" -> "Firma"
                "urun" -> "Ürün"
                "urun_tipi" -> "Ürün Tipi"
                "personel" -> "Personel"
                "mesaj_sablon" -> "Mesaj Şablon"
                "unvan" -> "Ünvan"
                "etiket_sablon" -> "Etiket Şablon"
                "etiket_sablon_bilesen" -> "Etiket Bileşen"
                "etiket_sayfa_ayar" -> "Sayfa Ayar"
                "call_logs" -> "Arama Kaydı"
                "delete_log" -> "Silme Kaydı"
                else -> change.tableName
            }

            val actionTr = when (change.actionType) {
                ChangeLog.ActionType.INSERT -> "Eklendi"
                ChangeLog.ActionType.UPDATE -> "Güncellendi"
                ChangeLog.ActionType.DELETE -> "Silindi"
            }

            holder.text1.text = "$icon $timeStr - $tableNameTr $actionTr"

            val detailText = if (!change.details.isNullOrEmpty()) {
                change.details
            } else {
                "ID: ${change.recordId}"
            }

            holder.text2.text = detailText

            // Arka plan rengi
            holder.itemView.setBackgroundColor(
                when (change.actionType) {
                    ChangeLog.ActionType.INSERT -> 0x20_00FF00 // Hafif yeşil
                    ChangeLog.ActionType.UPDATE -> 0x20_FFA500 // Hafif turuncu
                    ChangeLog.ActionType.DELETE -> 0x20_FF0000 // Hafif kırmızı
                }
            )
        }

        class ViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
            val text1: TextView = itemView.findViewById(android.R.id.text1)
            val text2: TextView = itemView.findViewById(android.R.id.text2)
        }
    }
}