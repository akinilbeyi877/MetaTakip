package com.example.metatakip.feature_backup.data



/**
 * Veritabanındaki değişiklikleri takip eden model sınıfı
 * Her INSERT, UPDATE, DELETE işlemi buraya kaydedilir
 */
data class ChangeLog(
    val id: Long = 0,
    val tableName: String,           // Hangi tablo (musteri, siparis, etc)
    val actionType: ActionType,      // INSERT, UPDATE, DELETE
    val recordId: Long,              // Değişen kaydın ID'si
    val changedAt: Long,             // Değişiklik zamanı (timestamp)
    val userId: Int = 0,             // Hangi kullanıcı yaptı (opsiyonel)
    val details: String? = null,     // Detaylı bilgi (eski/yeni değerler)
    var synced: Boolean = false      // Yedekleme senkronize edildi mi?
) {
    enum class ActionType {
        INSERT,
        UPDATE,
        DELETE
    }

    // Ekran için formatlı açıklama
    fun getDisplayMessage(): String {
        val timeStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date(changedAt))

        val actionIcon = when (actionType) {
            ActionType.INSERT -> "🟢"
            ActionType.UPDATE -> "🔄"
            ActionType.DELETE -> "🔴"
        }

        val tableNameTr = when (tableName) {
            "musteri" -> "Müşteri"
            "siparis" -> "Sipariş"
            "firma" -> "Firma"
            "urun" -> "Ürün"
            "urun_tipi" -> "Ürün Tipi"
            "personel" -> "Personel"
            else -> tableName
        }

        val actionTr = when (actionType) {
            ActionType.INSERT -> "Eklendi"
            ActionType.UPDATE -> "Güncellendi"
            ActionType.DELETE -> "Silindi"
        }

        return "$actionIcon $timeStr - $tableNameTr $actionTr (ID: $recordId)"
    }

    // Detaylı bilgi için
    fun getDetailedMessage(): String {
        val base = getDisplayMessage()
        return if (details != null) "$base\n   📝 $details" else base
    }
}