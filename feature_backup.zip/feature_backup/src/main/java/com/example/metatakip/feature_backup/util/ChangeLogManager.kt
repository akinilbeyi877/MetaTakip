package com.example.metatakip.feature_backup.util

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.util.Log
import com.example.metatakip.feature_backup.data.ChangeLog
import com.example.metatakip.feature_backup.db.MigrationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object ChangeLogManager {
    private const val TAG = "ChangeLogManager"

    // Son değişikliklerin listesi
    private val _recentChanges = MutableStateFlow<List<ChangeLog>>(emptyList())
    val recentChanges: StateFlow<List<ChangeLog>> = _recentChanges.asStateFlow()

    // Son kontrol zamanı
    private var lastCheckTime: Long = System.currentTimeMillis()

    // Dinleyiciler
    private val listeners = mutableListOf<OnChangeListener>()
    private var onChangesSavedListener: ((List<ChangeLog>) -> Unit)? = null

    interface OnChangeListener {
        fun onNewChange(change: ChangeLog)
        fun onChangesUpdated(changes: List<ChangeLog>)
    }

    /**
     * Değişiklikler kaydedildiğinde tetiklenecek listener
     */
    fun setOnChangesSavedListener(listener: (List<ChangeLog>) -> Unit) {
        this.onChangesSavedListener = listener
    }

    /**
     * Veritabanını migration için kontrol et
     */
    fun initialize(context: Context) {
        MigrationHelper.checkAndMigrate(context)
        Log.d(TAG, "✅ ChangeLogManager başlatıldı")
    }

    /**
     * Yeni değişiklikleri kontrol et
     */
    fun checkForNewChanges(context: Context): List<ChangeLog> {
        val db = openDbReadable(context)
        val newChanges = mutableListOf<ChangeLog>()

        try {
            val cursor = db.rawQuery("""
                SELECT id, table_name, action_type, record_id, changed_at, user_id, details, synced 
                FROM change_log 
                WHERE changed_at > ? 
                ORDER BY changed_at DESC
            """, arrayOf((lastCheckTime / 1000).toString()))

            while (cursor.moveToNext()) {
                val change = cursorToChangeLog(cursor)
                newChanges.add(change)
            }
            cursor.close()

            if (newChanges.isNotEmpty()) {
                lastCheckTime = System.currentTimeMillis()

                // Recent changes listesini güncelle
                val currentList = _recentChanges.value.toMutableList()
                currentList.addAll(0, newChanges)
                _recentChanges.value = currentList.take(100)

                // Dinleyicilere bildir
                newChanges.forEach { change ->
                    listeners.forEach { it.onNewChange(change) }
                }
                listeners.forEach { it.onChangesUpdated(_recentChanges.value) }

                // YENİ: Değişiklikler kaydedildi listener'ını tetikle
                onChangesSavedListener?.invoke(newChanges)

                Log.d(TAG, "📝 ${newChanges.size} yeni değişiklik bulundu, anlık yedek tetiklendi")
            }

        } catch (e: Exception) {
            Log.e(TAG, "Değişiklik kontrolü hatası: ${e.message}")
        } finally {
            db.close()
        }

        return newChanges
    }

    /**
     * Belirli bir tarihten sonraki tüm değişiklikleri getir
     */
    fun getChangesSince(context: Context, sinceTime: Long): List<ChangeLog> {
        val db = openDbReadable(context)
        val changes = mutableListOf<ChangeLog>()

        try {
            val cursor = db.rawQuery("""
                SELECT id, table_name, action_type, record_id, changed_at, user_id, details, synced 
                FROM change_log 
                WHERE changed_at > ? 
                ORDER BY changed_at DESC
            """, arrayOf((sinceTime / 1000).toString()))

            while (cursor.moveToNext()) {
                changes.add(cursorToChangeLog(cursor))
            }
            cursor.close()

        } catch (e: Exception) {
            Log.e(TAG, "Değişiklik getirme hatası: ${e.message}")
        } finally {
            db.close()
        }

        return changes
    }

    /**
     * Senkronize edilmemiş değişiklikleri getir
     */
    fun getUnsyncedChanges(context: Context): List<ChangeLog> {
        val db = openDbReadable(context)
        val changes = mutableListOf<ChangeLog>()

        try {
            val cursor = db.rawQuery("""
                SELECT id, table_name, action_type, record_id, changed_at, user_id, details, synced 
                FROM change_log 
                WHERE synced = 0 
                ORDER BY changed_at ASC
            """, null)

            while (cursor.moveToNext()) {
                changes.add(cursorToChangeLog(cursor))
            }
            cursor.close()

        } catch (e: Exception) {
            Log.e(TAG, "Senkronize edilmemiş değişiklikler getirme hatası: ${e.message}")
        } finally {
            db.close()
        }

        return changes
    }

    /**
     * Değişiklikleri senkronize edildi olarak işaretle
     */
    fun markAsSynced(context: Context, changeIds: List<Long>) {
        if (changeIds.isEmpty()) return

        val db = openDbWritable(context)
        try {
            val ids = changeIds.joinToString(",")
            db.execSQL("UPDATE change_log SET synced = 1 WHERE id IN ($ids)")
            Log.d(TAG, "✅ ${changeIds.size} değişiklik senkronize edildi olarak işaretlendi")
        } catch (e: Exception) {
            Log.e(TAG, "Senkronizasyon işaretleme hatası: ${e.message}")
        } finally {
            db.close()
        }
    }

    /**
     * Tüm değişiklikleri temizle
     */
    fun cleanOldChanges(context: Context, olderThanDays: Int = 30) {
        val db = openDbWritable(context)
        try {
            val cutoffTime = (System.currentTimeMillis() / 1000) - (olderThanDays * 24 * 60 * 60)
            db.execSQL("DELETE FROM change_log WHERE changed_at < ? AND synced = 1", arrayOf(cutoffTime.toString()))
            Log.d(TAG, "🧹 ${olderThanDays} günden eski senkronize edilmiş değişiklikler temizlendi")
        } catch (e: Exception) {
            Log.e(TAG, "Temizleme hatası: ${e.message}")
        } finally {
            db.close()
        }
    }

    /**
     * Dinleyici ekle
     */
    fun addListener(listener: OnChangeListener) {
        listeners.add(listener)
    }

    /**
     * Dinleyici çıkar
     */
    fun removeListener(listener: OnChangeListener) {
        listeners.remove(listener)
    }

    /**
     * Son kontrol zamanını manuel olarak ayarla
     */
    fun setLastCheckTime(time: Long) {
        lastCheckTime = time
    }

    /**
     * Son değişiklikleri manuel olarak güncelle
     */
    fun refreshRecentChanges(context: Context) {
        val db = openDbReadable(context)
        try {
            val cursor = db.rawQuery("""
                SELECT id, table_name, action_type, record_id, changed_at, user_id, details, synced 
                FROM change_log 
                ORDER BY changed_at DESC 
                LIMIT 100
            """, null)

            val changes = mutableListOf<ChangeLog>()
            while (cursor.moveToNext()) {
                changes.add(cursorToChangeLog(cursor))
            }
            cursor.close()

            _recentChanges.value = changes
            listeners.forEach { it.onChangesUpdated(changes) }

            if (changes.isNotEmpty()) {
                lastCheckTime = changes.first().changedAt * 1000 + 1
            }

            Log.d(TAG, "🔄 Son değişiklikler yenilendi: ${changes.size} kayıt")

        } catch (e: Exception) {
            Log.e(TAG, "Yenileme hatası: ${e.message}")
        } finally {
            db.close()
        }
    }

    /**
     * Cursor'dan ChangeLog nesnesi oluştur
     */
    private fun cursorToChangeLog(cursor: Cursor): ChangeLog {
        val id = cursor.getLong(0)
        val tableName = cursor.getString(1)
        val actionTypeStr = cursor.getString(2)
        val recordId = cursor.getLong(3)
        val changedAt = cursor.getLong(4) * 1000
        val userId = cursor.getInt(5)
        val details = cursor.getString(6)
        val synced = cursor.getInt(7) == 1

        val actionType = when (actionTypeStr) {
            "INSERT" -> ChangeLog.ActionType.INSERT
            "UPDATE" -> ChangeLog.ActionType.UPDATE
            "DELETE" -> ChangeLog.ActionType.DELETE
            else -> ChangeLog.ActionType.INSERT
        }

        return ChangeLog(
            id = id,
            tableName = tableName,
            actionType = actionType,
            recordId = recordId,
            changedAt = changedAt,
            userId = userId,
            details = details,
            synced = synced
        )
    }

    /**
     * Okunabilir veritabanı aç
     */
    private fun openDbReadable(context: Context): SQLiteDatabase {
        val dbFile = DbFilePaths.dbFile(context)
        return SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
    }

    /**
     * Yazılabilir veritabanı aç
     */
    private fun openDbWritable(context: Context): SQLiteDatabase {
        val dbFile = DbFilePaths.dbFile(context)
        return SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
    }
}