package com.example.metatakip.feature_backup.ui

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.NestedScrollView
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.metatakip.feature_backup.R
import com.example.metatakip.feature_backup.data.ChangeLog
import com.example.metatakip.feature_backup.data.ImportRowResult
import com.example.metatakip.feature_backup.data.TableCatalog
import com.example.metatakip.feature_backup.drive.DriveAuthManager
import com.example.metatakip.feature_backup.drive.DriveLockManager
import com.example.metatakip.feature_backup.drive.DriveUploadHelper
import com.example.metatakip.feature_backup.local.CsvImportManager
import com.example.metatakip.feature_backup.local.LocalBackupManager
import com.example.metatakip.feature_backup.util.AppRestartUtil
import com.example.metatakip.feature_backup.util.BackupFolderType
import com.example.metatakip.feature_backup.util.BackupPreferences
import com.example.metatakip.feature_backup.util.ChangeLogManager
import com.example.metatakip.feature_backup.util.CsvExporter
import com.example.metatakip.feature_backup.util.DbFilePaths
import com.example.metatakip.feature_backup.util.FullBackupManager
import com.example.metatakip.feature_backup.util.PartialBackupManager
import com.example.metatakip.feature_backup.util.TimeUtils
import com.example.metatakip.feature_backup.worker.AutoBackupLogStore
import com.example.metatakip.feature_backup.worker.AutoBackupScheduler
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class BackupRestoreActivity : AppCompatActivity() {

    private lateinit var tvAccount: TextView
    private lateinit var tvImportPreview: TextView
    private lateinit var tvLog: TextView
    private lateinit var tvCurrentFolder: TextView
    private lateinit var tvEmptyChanges: TextView
    private lateinit var tvAutoStatus: TextView

    private lateinit var tvAutoTime1: TextView
    private lateinit var tvAutoTime2: TextView
    private lateinit var tvAutoTime3: TextView

    private lateinit var etFolderName: EditText

    private lateinit var btnSaveFolderName: Button
    private lateinit var btnPickBackupFolder: Button
    private lateinit var btnBack: Button

    private lateinit var btnConnectDrive: LinearLayout
    private lateinit var btnDisconnectDrive: LinearLayout
    private lateinit var btnEnableAuto: LinearLayout
    private lateinit var btnFullBackup: LinearLayout
    private lateinit var btnPartialBackup: LinearLayout
    private lateinit var btnExportCsvAll: LinearLayout
    private lateinit var btnImportCsv: LinearLayout
    private lateinit var btnRestoreFromZip: LinearLayout

    private lateinit var layoutTime1: LinearLayout
    private lateinit var layoutTime2: LinearLayout
    private lateinit var layoutTime3: LinearLayout

    private lateinit var rvRecentChanges: RecyclerView
    private lateinit var nestedScrollViewLog: NestedScrollView
    private lateinit var changeLogAdapter: ChangeLogAdapter

    private lateinit var driveAuthManager: DriveAuthManager

    private val checkHandler = Handler(Looper.getMainLooper())
    private var checkRunnable: Runnable? = null
    private val checkInterval = 2000L

    private val pickBackupFolderLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode != Activity.RESULT_OK) return@registerForActivityResult

            val data = result.data ?: return@registerForActivityResult
            val treeUri = data.data ?: return@registerForActivityResult

            try {
                val takeFlags = data.flags and
                        (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)

                contentResolver.takePersistableUriPermission(treeUri, takeFlags)
                BackupPreferences.setBackupFolderUri(this, treeUri.toString())

                val pickedFolder = DocumentFile.fromTreeUri(this, treeUri)
                val folderDisplayName = pickedFolder?.name

                if (!folderDisplayName.isNullOrBlank()) {
                    BackupPreferences.setBackupFolderName(this, folderDisplayName)
                }

                updateFolderNameDisplay()
                log("📁 Gerçek klasör seçildi: $treeUri")
                toast("✅ Klasör seçildi")
            } catch (e: Exception) {
                log("❌ Klasör seçme hatası: ${e.message}")
                toast("Klasör seçme hatası: ${e.message}")
            }
        }

    private val pickRestoreZipLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode != Activity.RESULT_OK) return@registerForActivityResult

            val uri = result.data?.data ?: return@registerForActivityResult
            val fileName = DocumentFile.fromSingleUri(this, uri)?.name
                ?: uri.lastPathSegment
                ?: "backup.zip"

            AlertDialog.Builder(this)
                .setTitle("📦 Geri Yükleme Tipi")
                .setMessage("Dosya: $fileName\n\nBu dosyayı nasıl geri yüklemek istiyorsunuz?")
                .setPositiveButton("📦 Tam Restore") { _, _ ->
                    AlertDialog.Builder(this)
                        .setTitle("Tam Geri Yükleme")
                        .setMessage("Bu işlem mevcut veritabanını tamamen değiştirir. Devam edilsin mi?")
                        .setPositiveButton("Evet") { _, _ -> restoreFullBackup(uri) }
                        .setNegativeButton("Vazgeç", null)
                        .show()
                }
                .setNeutralButton("🧩 Kısmi Restore") { _, _ ->
                    showTablePickerDialogForRestore(uri)
                }
                .setNegativeButton("İptal", null)
                .show()
        }

    private val pickCsvFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult

            lifecycleScope.launch {
                try {
                    val fileName = uri.lastPathSegment ?: "dosya.csv"
                    log("📂 CSV import başlatıldı: $fileName")

                    val results = withContext(Dispatchers.IO) {
                        CsvImportManager.importCsvFile(
                            context = this@BackupRestoreActivity,
                            fileUri = uri,
                            contentResolver = contentResolver
                        )
                    }

                    val successCount = results.count { it.status == ImportRowResult.Status.OK }
                    val errorCount = results.count { it.status == ImportRowResult.Status.ERROR }

                    log("✅ Başarılı: $successCount")
                    log("❌ Hatalı: $errorCount")

                    showCsvImportPreview(results)
                    toast("CSV Import tamam: $successCount satır işlendi")
                    checkForNewChanges()
                } catch (e: Exception) {
                    log("❌ CSV import hatası: ${e.message}")
                    toast("CSV Import hatası: ${e.message}")
                }
            }
        }

    private val signInLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(ApiException::class.java)
                BackupPreferences.setDriveConnected(this, true)
                BackupPreferences.setDriveEmail(this, account.email)
                updateAccountInfo()
                log("✅ Drive bağlandı: ${account.email}")
                toast("Drive bağlantısı başarılı")
            } catch (e: Exception) {
                log("❌ Drive bağlantı hatası: ${e.message}")
                toast("Drive bağlantısı başarısız")
            }
        }

    private val changeListener = object : ChangeLogManager.OnChangeListener {
        override fun onNewChange(change: ChangeLog) {
            runOnUiThread {
                updateRecentChanges()
                log("📝 ${change.getDisplayMessage()}")
            }
        }

        override fun onChangesUpdated(changes: List<ChangeLog>) {
            runOnUiThread { updateRecentChanges() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_backup_restore)

        driveAuthManager = DriveAuthManager(this)

        bindViews()
        setupRecyclerView()
        updateAccountInfo()
        updateFolderNameDisplay()
        loadSavedTimes()
        updateAutoBackupButtonText()
        setClickListeners()

        lifecycleScope.launch {
            AutoBackupLogStore.logs.collect { line ->
                log(line)
            }
        }

        ChangeLogManager.initialize(this)
        ChangeLogManager.addListener(changeListener)
        setupInstantBackup()
        loadRecentChanges()
        startPeriodicCheck()

        log("🚀 BackupRestoreActivity başlatıldı")
        log("📁 Klasör adı: ${BackupPreferences.getBackupFolderName(this)}")
        log("📂 Klasör URI: ${BackupPreferences.getBackupFolderUri(this) ?: "Seçilmedi"}")
    }

    override fun onResume() {
        super.onResume()
        checkForNewChanges()
        updateFolderNameDisplay()
        loadSavedTimes()
        updateAutoBackupButtonText()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPeriodicCheck()
        ChangeLogManager.removeListener(changeListener)
    }

    private fun bindViews() {
        tvAccount = findViewById(R.id.tvAccount)
        tvImportPreview = findViewById(R.id.tvImportPreview)
        tvLog = findViewById(R.id.tvLog)
        tvCurrentFolder = findViewById(R.id.tvCurrentFolder)
        tvEmptyChanges = findViewById(R.id.tvEmptyChanges)
        tvAutoStatus = findViewById(R.id.tvAutoStatus)

        tvAutoTime1 = findViewById(R.id.tvAutoTime1)
        tvAutoTime2 = findViewById(R.id.tvAutoTime2)
        tvAutoTime3 = findViewById(R.id.tvAutoTime3)

        etFolderName = findViewById(R.id.etFolderName)

        btnSaveFolderName = findViewById(R.id.btnSaveFolderName)
        btnPickBackupFolder = findViewById(R.id.btnPickBackupFolder)
        btnBack = findViewById(R.id.btnBack)

        btnConnectDrive = findViewById(R.id.btnConnectDrive)
        btnDisconnectDrive = findViewById(R.id.btnDisconnectDrive)
        btnEnableAuto = findViewById(R.id.btnEnableAuto)
        btnFullBackup = findViewById(R.id.btnFullBackup)
        btnPartialBackup = findViewById(R.id.btnPartialBackup)
        btnExportCsvAll = findViewById(R.id.btnExportCsvAll)
        btnImportCsv = findViewById(R.id.btnImportCsv)
        btnRestoreFromZip = findViewById(R.id.btnRestoreFromZip)

        layoutTime1 = findViewById(R.id.layoutTime1)
        layoutTime2 = findViewById(R.id.layoutTime2)
        layoutTime3 = findViewById(R.id.layoutTime3)

        rvRecentChanges = findViewById(R.id.rvRecentChanges)
        nestedScrollViewLog = findViewById(R.id.nestedScrollViewLog)
    }

    private fun setupRecyclerView() {
        changeLogAdapter = ChangeLogAdapter()
        val layoutManager = LinearLayoutManager(this)
        layoutManager.stackFromEnd = true
        layoutManager.reverseLayout = true
        rvRecentChanges.layoutManager = layoutManager
        rvRecentChanges.adapter = changeLogAdapter
    }

    private fun setClickListeners() {
        btnSaveFolderName.setOnClickListener {
            val newFolderName = etFolderName.text.toString().trim()
            if (newFolderName.isBlank()) {
                toast("Lütfen klasör adı girin")
                return@setOnClickListener
            }

            BackupPreferences.setBackupFolderName(this, newFolderName)
            updateFolderNameDisplay()
            log("📁 Klasör adı kaydedildi: $newFolderName")
            toast("✅ Klasör adı kaydedildi")
        }

        btnPickBackupFolder.setOnClickListener {
            openBackupFolderPicker()
        }

        btnConnectDrive.setOnClickListener {
            val signInIntent = driveAuthManager.getSignInClient().signInIntent
            signInLauncher.launch(signInIntent)
        }

        btnDisconnectDrive.setOnClickListener {
            driveAuthManager.signOut(this) {
                BackupPreferences.setDriveConnected(this, false)
                BackupPreferences.setDriveEmail(this, null)
                BackupPreferences.setAutoBackupEnabled(this, false)
                AutoBackupScheduler.cancelAll(this)
                updateAccountInfo()
                updateAutoBackupButtonText()
                log("🔌 Drive bağlantısı kaldırıldı")
                toast("Bağlantı kaldırıldı")
            }
        }

        layoutTime1.setOnClickListener { showTimePicker(tvAutoTime1) }
        layoutTime2.setOnClickListener { showTimePicker(tvAutoTime2) }
        layoutTime3.setOnClickListener { showTimePicker(tvAutoTime3) }

        btnEnableAuto.setOnClickListener {
            val current = BackupPreferences.isAutoBackupEnabled(this)

            if (!current) {
                if (!BackupPreferences.isDriveConnected(this)) {
                    toast("Önce Drive hesabı bağlanmalı")
                    return@setOnClickListener
                }

                val t1 = normalizeTime(tvAutoTime1.text.toString(), "09:00")
                val t2 = normalizeTime(tvAutoTime2.text.toString(), "14:00")
                val t3 = normalizeTime(tvAutoTime3.text.toString(), "21:00")

                try {
                    BackupPreferences.setAutoBackupTime1(this, t1)
                    BackupPreferences.setAutoBackupTime2(this, t2)
                    BackupPreferences.setAutoBackupTime3(this, t3)

                    tvAutoTime1.text = t1
                    tvAutoTime2.text = t2
                    tvAutoTime3.text = t3

                    AutoBackupScheduler.scheduleAll(this, t1, t2, t3)
                    BackupPreferences.setAutoBackupEnabled(this, true)
                    updateAutoBackupButtonText()

                    log("🤖 Otomatik yedek AÇILDI")
                    log("🕒 1. zaman: $t1")
                    log("🕒 2. zaman: $t2")
                    log("🕒 3. zaman: $t3")
                } catch (e: Exception) {
                    log("❌ Saat ayarı hatası: ${e.message}")
                    toast("Saat formatı HH:mm olmalı")
                }
            } else {
                AutoBackupScheduler.cancelAll(this)
                BackupPreferences.setAutoBackupEnabled(this, false)
                updateAutoBackupButtonText()
                log("🤖 Otomatik yedek KAPATILDI")
            }
        }

        btnFullBackup.setOnClickListener { takeFullBackup() }
        btnPartialBackup.setOnClickListener { takePartialBackup() }
        btnExportCsvAll.setOnClickListener { exportAllTablesCsv() }

        btnImportCsv.setOnClickListener {
            pickCsvFile.launch(
                arrayOf(
                    "text/csv",
                    "text/comma-separated-values",
                    "application/csv",
                    "*/*"
                )
            )
        }

        btnRestoreFromZip.setOnClickListener {
            openRestoreZipPickerFromLastFolder()
        }

        btnBack.setOnClickListener { finish() }
    }

    private fun loadSavedTimes() {
        tvAutoTime1.text = normalizeTime(BackupPreferences.getAutoBackupTime1(this), "09:00")
        tvAutoTime2.text = normalizeTime(BackupPreferences.getAutoBackupTime2(this), "14:00")
        tvAutoTime3.text = normalizeTime(BackupPreferences.getAutoBackupTime3(this), "21:00")
    }

    private fun normalizeTime(value: String?, defaultValue: String): String {
        val text = value?.trim().orEmpty()
        return if (text.matches(Regex("^\\d{2}:\\d{2}$"))) text else defaultValue
    }

    private fun showTimePicker(target: TextView) {
        val current = target.text.toString().trim()
        val parts = current.split(":")
        val initialHour = parts.getOrNull(0)?.toIntOrNull() ?: 9
        val initialMinute = parts.getOrNull(1)?.toIntOrNull() ?: 0

        TimePickerDialog(
            this,
            { _, selectedHour, selectedMinute ->
                val formatted = String.format(
                    Locale.getDefault(),
                    "%02d:%02d",
                    selectedHour,
                    selectedMinute
                )
                target.text = formatted
            },
            initialHour,
            initialMinute,
            true
        ).show()
    }

    private fun openBackupFolderPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)

            val currentUri = BackupPreferences.getBackupFolderUri(this@BackupRestoreActivity)
            if (!currentUri.isNullOrBlank()) {
                try {
                    putExtra("android.provider.extra.INITIAL_URI", Uri.parse(currentUri))
                } catch (_: Exception) {
                }
            }
        }

        pickBackupFolderLauncher.launch(intent)
    }

    private fun openRestoreZipPickerFromLastFolder() {
        val savedFolderUriString = BackupPreferences.getBackupFolderUri(this)

        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

            if (!savedFolderUriString.isNullOrBlank()) {
                try {
                    putExtra("android.provider.extra.INITIAL_URI", Uri.parse(savedFolderUriString))
                } catch (_: Exception) {
                }
            }
        }

        pickRestoreZipLauncher.launch(intent)
    }

    private fun startPeriodicCheck() {
        checkRunnable = object : Runnable {
            override fun run() {
                lifecycleScope.launch {
                    try {
                        val newChanges = withContext(Dispatchers.IO) {
                            ChangeLogManager.checkForNewChanges(this@BackupRestoreActivity)
                        }
                        if (newChanges.isNotEmpty()) {
                            updateRecentChanges()
                        }
                    } catch (_: Exception) {
                    }
                }

                checkHandler.postDelayed(this, checkInterval)
            }
        }

        checkHandler.post(checkRunnable!!)
    }

    private fun stopPeriodicCheck() {
        checkRunnable?.let { checkHandler.removeCallbacks(it) }
        checkRunnable = null
    }

    private fun checkForNewChanges() {
        lifecycleScope.launch {
            val newChanges = withContext(Dispatchers.IO) {
                ChangeLogManager.checkForNewChanges(this@BackupRestoreActivity)
            }
            if (newChanges.isNotEmpty()) {
                withContext(Dispatchers.Main) { updateRecentChanges() }
            }
        }
    }

    private fun setupInstantBackup() {
        ChangeLogManager.setOnChangesSavedListener { changes ->
            lifecycleScope.launch {
                takeInstantBackup(changes)
            }
        }
    }

    private suspend fun takeInstantBackup(changes: List<ChangeLog>) {
        withContext(Dispatchers.Main) {
            log("⚡ ANLIK YEDEK BAŞLATILDI")
            log("📝 Değişiklik sayısı: ${changes.size}")

            changes.take(10).forEach { change ->
                val actionText = when (change.actionType) {
                    ChangeLog.ActionType.INSERT -> "INSERT"
                    ChangeLog.ActionType.UPDATE -> "UPDATE"
                    ChangeLog.ActionType.DELETE -> "DELETE"
                }
                log("⚡ $actionText → ${change.tableName} (id=${change.recordId})")
            }

            if (changes.size > 10) {
                log("… ve ${changes.size - 10} değişiklik daha")
            }
        }

        runWithDriveLock("Anlık yedek") {
            withContext(Dispatchers.IO) {
                try {
                    val tempZip = FullBackupManager(this@BackupRestoreActivity).createBackupZip()
                    val fileName = "anlik_${TimeUtils.timestamp()}.zip"

                    val savedFile = LocalBackupManager.saveToTodayFolder(
                        context = this@BackupRestoreActivity,
                        sourceFile = tempZip,
                        fileName = fileName,
                        type = BackupFolderType.INSTANT
                    )

                    val fileSizeKB = savedFile.length() / 1024
                    val folderName = BackupPreferences.getBackupFolderName(this@BackupRestoreActivity)
                    val today = TimeUtils.todayFolder()

                    withContext(Dispatchers.Main) {
                        log("📄 Dosya: $fileName")
                        log("📦 Boyut: $fileSizeKB KB")
                        log("📱 Telefon: /storage/emulated/0/Download/$folderName/instant/$today/")

                        if (BackupPreferences.isDriveConnected(this@BackupRestoreActivity)) {
                            log("☁️ Drive: $folderName/instant/$today/")
                            log("☁️ Drive yükleniyor...")
                        }
                    }

                    var driveUploaded = false
                    if (BackupPreferences.isDriveConnected(this@BackupRestoreActivity)) {
                        driveUploaded = DriveUploadHelper.uploadToDrive(
                            context = this@BackupRestoreActivity,
                            localFile = savedFile,
                            type = BackupFolderType.INSTANT
                        )
                    }

                    LocalBackupManager.deleteOldLocalBackups(this@BackupRestoreActivity)
                    BackupPreferences.setLastBackupTime(
                        this@BackupRestoreActivity,
                        System.currentTimeMillis()
                    )

                    withContext(Dispatchers.Main) {
                        if (BackupPreferences.isDriveConnected(this@BackupRestoreActivity)) {
                            if (driveUploaded) {
                                log("✅ Drive yükleme tamam")
                            } else {
                                log("❌ Drive yükleme başarısız")
                            }
                        }

                        log("✅ ANLIK YEDEK TAMAMLANDI")
                        log("────────────────────────────")
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        log("❌ ANLIK YEDEK HATASI")
                        log("❌ ${e.message ?: "Bilinmeyen hata"}")
                        log("────────────────────────────")
                    }
                }
            }
        }
    }

    private fun takeFullBackup() {
        lifecycleScope.launch {
            runWithDriveLock("Tam yedek") {
            try {
                val startTime = System.currentTimeMillis()
                val folderName = BackupPreferences.getBackupFolderName(this@BackupRestoreActivity)
                val todayStr = TimeUtils.todayFolder()
                val downloadsPath = "/storage/emulated/0/Download"
                val fileName = "tam_${TimeUtils.timestamp()}.zip"

                log("════════════════════════════════════════════════════")
                log("📦 Tam yedek başlatıldı")
                log("📄 Dosya adı: $fileName")
                log("📱 Telefon: $downloadsPath/$folderName/full/$todayStr/")

                if (BackupPreferences.isDriveConnected(this@BackupRestoreActivity)) {
                    log("☁️ Drive: $folderName/full/$todayStr/")
                }

                val savedFile = withContext(Dispatchers.IO) {
                    val tempZip = FullBackupManager(this@BackupRestoreActivity).createBackupZip()
                    LocalBackupManager.saveToTodayFolder(
                        context = this@BackupRestoreActivity,
                        sourceFile = tempZip,
                        fileName = fileName,
                        type = BackupFolderType.FULL
                    )
                }

                val fileSizeKB = savedFile.length() / 1024
                log("✅ Telefona kaydedildi: ${savedFile.absolutePath} ($fileSizeKB KB)")

                if (BackupPreferences.isDriveConnected(this@BackupRestoreActivity)) {
                    val uploaded = DriveUploadHelper.uploadToDrive(
                        context = this@BackupRestoreActivity,
                        localFile = savedFile,
                        type = BackupFolderType.FULL
                    )

                    if (uploaded) {
                        log("✅ Drive'a yüklendi: $folderName/full/$todayStr/${savedFile.name}")
                    } else {
                        log("❌ Drive yükleme başarısız")
                    }
                }

                LocalBackupManager.deleteOldLocalBackups(this@BackupRestoreActivity)
                BackupPreferences.setLastBackupTime(this@BackupRestoreActivity, System.currentTimeMillis())

                val totalTime = (System.currentTimeMillis() - startTime) / 1000
                log("✅ Tam yedek tamamlandı ($totalTime sn)")
                log("════════════════════════════════════════════════════")

                toast("✅ Tam yedek alındı: ${savedFile.name}")
                loadRecentChanges()
            } catch (e: Exception) {
                log("❌ Hata: ${e.message}")
                toast("Hata: ${e.message}")
            }
            }
        }
    }

    private fun takePartialBackup() {
        showTablePickerDialog(
            title = "Kısmi Yedek - Tabloları Seç",
            defaultSelected = defaultPartialSelection()
        ) { selectedTables ->
            lifecycleScope.launch {
                runWithDriveLock("Kısmi yedek") {
                try {
                    val startTime = System.currentTimeMillis()
                    val folderName = BackupPreferences.getBackupFolderName(this@BackupRestoreActivity)
                    val todayStr = TimeUtils.todayFolder()
                    val downloadsPath = "/storage/emulated/0/Download"
                    val fileName = "kismi_${TimeUtils.timestamp()}.zip"

                    log("════════════════════════════════════════════════════")
                    log("🧩 Kısmi yedek başlatıldı")
                    log("📄 Dosya adı: $fileName")
                    log("📋 Seçilen tablolar: ${selectedTables.size}")
                    log("📱 Telefon: $downloadsPath/$folderName/partial/$todayStr/")

                    val savedFile = withContext(Dispatchers.IO) {
                        val tempZip = PartialBackupManager(this@BackupRestoreActivity)
                            .createPartialZip(selectedTables)

                        LocalBackupManager.saveToTodayFolder(
                            context = this@BackupRestoreActivity,
                            sourceFile = tempZip,
                            fileName = fileName,
                            type = BackupFolderType.PARTIAL
                        )
                    }

                    val fileSizeKB = savedFile.length() / 1024
                    log("✅ Telefona kaydedildi: ${savedFile.absolutePath} ($fileSizeKB KB)")

                    if (BackupPreferences.isDriveConnected(this@BackupRestoreActivity)) {
                        val uploaded = DriveUploadHelper.uploadToDrive(
                            context = this@BackupRestoreActivity,
                            localFile = savedFile,
                            type = BackupFolderType.PARTIAL
                        )
                        if (uploaded) {
                            log("✅ Drive'a yüklendi: $folderName/partial/$todayStr/${savedFile.name}")
                        } else {
                            log("❌ Drive yükleme başarısız")
                        }
                    }

                    LocalBackupManager.deleteOldLocalBackups(this@BackupRestoreActivity)
                    BackupPreferences.setLastBackupTime(this@BackupRestoreActivity, System.currentTimeMillis())

                    val totalTime = (System.currentTimeMillis() - startTime) / 1000
                    log("✅ Kısmi yedek tamamlandı ($totalTime sn)")
                    log("════════════════════════════════════════════════════")

                    toast("✅ Kısmi yedek alındı: ${savedFile.name}")
                    loadRecentChanges()
                } catch (e: Exception) {
                    log("❌ Hata: ${e.message}")
                    toast("Hata: ${e.message}")
                }
                }
            }
        }
    }

    private fun exportAllTablesCsv() {
        lifecycleScope.launch {
            try {
                val startTime = System.currentTimeMillis()
                val folderName = BackupPreferences.getBackupFolderName(this@BackupRestoreActivity)
                val todayStr = TimeUtils.todayFolder()
                val downloadsPath = "/storage/emulated/0/Download"
                val exportFolderName = "csv_export_${TimeUtils.timestamp()}"

                log("════════════════════════════════════════════════════")
                log("📄 CSV export başlatıldı")
                log("📱 Telefon: $downloadsPath/$folderName/csv/$todayStr/$exportFolderName/")

                val exportFolder = withContext(Dispatchers.IO) {
                    val folder = LocalBackupManager.createTodaySubFolder(
                        context = this@BackupRestoreActivity,
                        type = BackupFolderType.CSV,
                        subFolderName = exportFolderName
                    )

                    val db = openDbReadOnly()
                    TableCatalog.ALL_TABLES.forEach { table ->
                        val csvFile = File(folder, "$table.csv")
                        CsvExporter.exportTableToFile(db, table, csvFile)
                    }
                    db.close()
                    folder
                }

                log("✅ CSV export tamamlandı: ${exportFolder.absolutePath}")

                if (BackupPreferences.isDriveConnected(this@BackupRestoreActivity)) {
                    withContext(Dispatchers.IO) {
                        val zipFile = File(cacheDir, "csv_export_${TimeUtils.timestamp()}.zip")
                        zipFolder(exportFolder, zipFile)

                        DriveUploadHelper.uploadToDrive(
                            context = this@BackupRestoreActivity,
                            localFile = zipFile,
                            type = BackupFolderType.CSV
                        )

                        zipFile.delete()
                    }
                    log("☁️ Drive'a yedeklendi")
                }

                val totalTime = (System.currentTimeMillis() - startTime) / 1000
                log("⏱️ Süre: $totalTime sn")
                log("════════════════════════════════════════════════════")
                toast("✅ CSV Export tamam")
                loadRecentChanges()
            } catch (e: Exception) {
                log("❌ CSV export hatası: ${e.message}")
                toast("CSV export hatası")
            }
        }
    }

    private fun zipFolder(folder: File, zipFile: File) {
        ZipOutputStream(FileOutputStream(zipFile)).use { zip ->
            folder.walk().forEach { file ->
                if (file.isFile) {
                    val relativePath = file.relativeTo(folder).path
                    zip.putNextEntry(ZipEntry(relativePath))
                    FileInputStream(file).use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
    }

    private fun restoreFullBackup(uri: Uri) {
        lifecycleScope.launch {
            try {
                log("📦 Tam restore başlatıldı")
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { input ->
                        FullBackupManager(this@BackupRestoreActivity).restoreDbFromZip(input)
                    } ?: throw IllegalStateException("Dosya açılamadı")
                }

                log("✅ Restore tamamlandı, uygulama yeniden başlatılıyor")
                toast("Restore tamam ✅")
                AppRestartUtil.restartApp(this@BackupRestoreActivity)
            } catch (e: Exception) {
                log("❌ Restore hatası: ${e.message}")
                toast("Restore hatası: ${e.message}")
            }
        }
    }

    private fun restorePartialBackup(uri: Uri, selectedTables: List<String>) {
        lifecycleScope.launch {
            try {
                log("🧩 Kısmi restore başlatıldı")
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { input ->
                        PartialBackupManager(this@BackupRestoreActivity).restoreFromPartialZip(
                            zipInput = input,
                            selectedTables = selectedTables,
                            protectUserTable = true
                        )
                    } ?: throw IllegalStateException("Dosya açılamadı")
                }

                log("✅ Kısmi restore tamamlandı")
                toast("Kısmi restore tamam ✅")
            } catch (e: Exception) {
                log("❌ Kısmi restore hatası: ${e.message}")
                toast("Hata: ${e.message}")
            }
        }
    }

    private fun showTablePickerDialogForRestore(uri: Uri) {
        val tables = TableCatalog.ALL_TABLES.toTypedArray()
        val selected = BooleanArray(tables.size) { idx -> tables[idx] != "user" }

        AlertDialog.Builder(this)
            .setTitle("🧩 Kısmi Restore - Tabloları Seç")
            .setMultiChoiceItems(tables, selected) { _, which, isChecked ->
                selected[which] = isChecked
            }
            .setPositiveButton("Tamam") { _, _ ->
                val picked = tables.indices.filter { selected[it] }.map { tables[it] }
                if (picked.isEmpty()) {
                    toast("En az 1 tablo seçmelisin")
                    return@setPositiveButton
                }

                AlertDialog.Builder(this)
                    .setTitle("Kısmi Geri Yükleme")
                    .setMessage("Seçili tablolar temizlenip yedekten geri yüklenecek. Devam edilsin mi?")
                    .setPositiveButton("Evet") { _, _ -> restorePartialBackup(uri, picked) }
                    .setNegativeButton("Vazgeç", null)
                    .show()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun loadRecentChanges() {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                ChangeLogManager.getChangesSince(this@BackupRestoreActivity, 0)
            }
            runOnUiThread { updateRecentChanges() }
        }
    }

    private fun updateRecentChanges() {
        val changes = ChangeLogManager.recentChanges.value
        if (changes.isEmpty()) {
            rvRecentChanges.visibility = View.GONE
            tvEmptyChanges.visibility = View.VISIBLE
        } else {
            rvRecentChanges.visibility = View.VISIBLE
            tvEmptyChanges.visibility = View.GONE
            changeLogAdapter.submitList(changes)
        }
    }

    private fun updateAccountInfo() {
        val email = BackupPreferences.getDriveEmail(this)
        tvAccount.text = if (email.isNullOrBlank()) "Hesap: Yok" else "Hesap: $email"
    }

    private fun updateFolderNameDisplay() {
        val folderName = BackupPreferences.getBackupFolderName(this)
        val folderUri = BackupPreferences.getBackupFolderUri(this)

        tvCurrentFolder.text = buildString {
            append("Klasör adı: ")
            append(folderName)
            append("\n")
            append("Seçili klasör: ")
            append(if (folderUri.isNullOrBlank()) "Seçilmedi" else "Ayarlı")
        }

        etFolderName.setText(folderName)
    }

    private fun updateAutoBackupButtonText() {
        val enabled = BackupPreferences.isAutoBackupEnabled(this)
        tvAutoStatus.text = if (enabled) "Durum: Açık" else "Durum: Kapalı"
        tvAutoStatus.setBackgroundColor(
            if (enabled) 0xFF16A34A.toInt() else 0xFFDC2626.toInt()
        )
        tvAutoStatus.setTextColor(0xFFFFFFFF.toInt())
        tvAutoStatus.setPadding(24, 14, 24, 14)
    }

    private fun showCsvImportPreview(results: List<CsvImportManager.CsvImportResult>) {
        val sb = StringBuilder()
        val successCount = results.count { it.status == ImportRowResult.Status.OK }
        val errorCount = results.count { it.status == ImportRowResult.Status.ERROR }

        sb.append("CSV Import Sonuçları\n")
        sb.append("Başarılı: $successCount\n")
        sb.append("Hatalı: $errorCount\n")

        tvImportPreview.text = sb.toString()
        tvImportPreview.visibility = View.VISIBLE
    }

    private fun showTablePickerDialog(
        title: String,
        defaultSelected: BooleanArray,
        onResult: (List<String>) -> Unit
    ) {
        val tables = TableCatalog.ALL_TABLES.toTypedArray()
        val selected = defaultSelected.clone()

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMultiChoiceItems(tables, selected) { _, which, isChecked ->
                selected[which] = isChecked
            }
            .setPositiveButton("Tamam") { _, _ ->
                val picked = tables.indices.filter { selected[it] }.map { tables[it] }
                if (picked.isEmpty()) {
                    toast("En az 1 tablo seçmelisin")
                } else {
                    onResult(picked)
                }
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun defaultPartialSelection(): BooleanArray {
        return BooleanArray(TableCatalog.ALL_TABLES.size) { idx ->
            TableCatalog.ALL_TABLES[idx] != "user"
        }
    }


    private suspend fun <T> runWithDriveLock(
        operationName: String,
        block: suspend () -> T
    ): T? {
        if (!BackupPreferences.isDriveConnected(this)) {
            return block()
        }

        withContext(Dispatchers.Main) {
            log("⏳ $operationName için sıra kontrol ediliyor...")
            toast("İşleminiz kontrol ediliyor...")
        }

        val acquire = DriveLockManager.acquireLock(this, waitTimeoutMs = 30_000L) { message ->
            withContext(Dispatchers.Main) {
                log("⏳ $message")
            }
        }

        if (!acquire.acquired) {
            withContext(Dispatchers.Main) {
                log("⚠️ $operationName başlatılamadı: ${acquire.reason}")
                toast("Başka cihaz işlem yapıyor. Lütfen bekleyin.")
            }
            return null
        }

        withContext(Dispatchers.Main) {
            log("🔒 Sıra alındı: $operationName")
            log("☁️ Güncel yedek üstünden işlem devam edecek")
            toast("Sıra size geldi, işlem başladı")
        }

        return try {
            block()
        } finally {
            val released = DriveLockManager.releaseLock(this)
            withContext(Dispatchers.Main) {
                if (released) {
                    log("🔓 Kilit bırakıldı")
                } else {
                    log("⚠️ Kilit bırakılırken kontrol gerekli")
                }
            }
        }
    }

    private fun openDbReadOnly(): SQLiteDatabase {
        return SQLiteDatabase.openDatabase(
            DbFilePaths.dbFile(this).absolutePath,
            null,
            SQLiteDatabase.OPEN_READONLY
        )
    }

    private fun log(msg: String) {
        runOnUiThread {
            tvLog.append("$msg\n")
            nestedScrollViewLog.post {
                nestedScrollViewLog.fullScroll(View.FOCUS_DOWN)
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}