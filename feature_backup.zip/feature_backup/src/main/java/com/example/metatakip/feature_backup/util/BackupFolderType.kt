package com.example.metatakip.feature_backup.util

enum class BackupFolderType(val folderName: String) {
    FULL("full"),
    PARTIAL("partial"),
    INSTANT("instant"),
    CSV("csv")
}