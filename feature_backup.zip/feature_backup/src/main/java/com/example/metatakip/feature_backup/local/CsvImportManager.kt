package com.example.metatakip.feature_backup.local

import android.content.ContentResolver
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.provider.OpenableColumns
import com.example.metatakip.feature_backup.data.ImportRowResult
import com.example.metatakip.feature_backup.data.TableCatalog
import com.example.metatakip.feature_backup.util.DbFilePaths
import java.io.File
import java.io.FileOutputStream

object CsvImportManager {

    data class CsvImportResult(
        val table: String,
        val rowIndex: Int,
        val status: ImportRowResult.Status,
        val message: String
    )

    suspend fun importCsvFile(
        context: Context,
        fileUri: Uri,
        contentResolver: ContentResolver
    ): List<CsvImportResult> {
        val results = mutableListOf<CsvImportResult>()

        val fileName = getFileName(contentResolver, fileUri) ?: "unknown.csv"
        if (!fileName.endsWith(".csv")) {
            return listOf(CsvImportResult(
                table = "unknown",
                rowIndex = 0,
                status = ImportRowResult.Status.ERROR,
                message = "CSV dosyası değil: $fileName"
            ))
        }

        val table = fileName.removeSuffix(".csv")

        if (!TableCatalog.ALL_TABLES.contains(table)) {
            return listOf(CsvImportResult(
                table = table,
                rowIndex = 0,
                status = ImportRowResult.Status.ERROR,
                message = "Geçersiz tablo adı: $table"
            ))
        }

        val tempFile = File(context.cacheDir, "temp_import_${System.currentTimeMillis()}.csv")
        try {
            contentResolver.openInputStream(fileUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: throw IllegalStateException("Dosya açılamadı")

            val dbFile = DbFilePaths.dbFile(context)
            val db = SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)

            try {
                db.beginTransaction()

                val lines = tempFile.readLines()
                if (lines.isNotEmpty()) {
                    // Header satırını al (ID dahil tüm kolonlar)
                    val headers = lines[0].split(",").map { it.trim().replace("\"", "") }

                    // Data satırları
                    lines.drop(1).forEachIndexed { index, line ->
                        if (line.isBlank()) return@forEachIndexed

                        try {
                            val values = parseCsvLine(line)
                            val rowMap = headers.zip(values).toMap()

                            // Validation yap
                            val validation = TableCatalog.validateRow(table, rowMap, index + 1)

                            if (validation.status == ImportRowResult.Status.OK) {
                                // ID KOLONU DAHİL TÜM KOLONLARI KULLAN!
                                val cols = headers.joinToString(",")
                                val qs = headers.joinToString(",") { "?" }

                                // REPLACE INTO kullan - ID varsa güncelle, yoksa ekle
                                val sql = "INSERT OR REPLACE INTO $table ($cols) VALUES ($qs)"

                                val args = values.map { v ->
                                    if (v.isBlank() || v == "null") null else v
                                }.toTypedArray()

                                db.execSQL(sql, args)

                                val idValue = if (headers.contains("id") || headers.contains("_id")) {
                                    " (ID: ${values[0]})"
                                } else ""

                                results.add(CsvImportResult(
                                    table = table,
                                    rowIndex = index + 1,
                                    status = ImportRowResult.Status.OK,
                                    message = "Eklendi/Güncellendi$idValue"
                                ))
                            } else {
                                results.add(CsvImportResult(
                                    table = table,
                                    rowIndex = index + 1,
                                    status = validation.status,
                                    message = validation.message
                                ))
                            }
                        } catch (e: Exception) {
                            results.add(CsvImportResult(
                                table = table,
                                rowIndex = index + 1,
                                status = ImportRowResult.Status.ERROR,
                                message = "Satır ${index + 1} hatası: ${e.message}"
                            ))
                        }
                    }
                }

                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
                db.close()
            }

        } catch (e: Exception) {
            results.add(CsvImportResult(
                table = table,
                rowIndex = 0,
                status = ImportRowResult.Status.ERROR,
                message = "Dosya işleme hatası: ${e.message}"
            ))
        } finally {
            tempFile.delete()
        }

        return results
    }

    private fun getFileName(contentResolver: ContentResolver, uri: Uri): String? {
        var fileName: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) {
                fileName = cursor.getString(nameIndex)
            }
        }
        return fileName
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false

        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' -> {
                    if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                        current.append('"')
                        i += 2
                    } else {
                        inQuotes = !inQuotes
                        i++
                    }
                }
                c == ',' && !inQuotes -> {
                    result.add(current.toString().trim())
                    current.clear()
                    i++
                }
                else -> {
                    current.append(c)
                    i++
                }
            }
        }
        result.add(current.toString().trim())

        return result
    }
}