package com.example.metatakip.feature_backup.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.metatakip.feature_backup.drive.DriveLockManager
import com.example.metatakip.feature_backup.drive.DriveUploadHelper
import com.example.metatakip.feature_backup.local.LocalBackupManager
import com.example.metatakip.feature_backup.util.BackupFolderType
import com.example.metatakip.feature_backup.util.BackupPreferences
import com.example.metatakip.feature_backup.util.FullBackupManager
import com.example.metatakip.feature_backup.util.TimeUtils

class BackupWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val context = applicationContext

        return try {
            val slot = inputData.getInt("slot", 1)

            AutoBackupLogStore.addLog("⏰ OTOMATİK YEDEK BAŞLADI (Zaman-$slot)")

            val tempZip = FullBackupManager(context).createBackupZip()
            val fileName = "otomatik_${slot}_${TimeUtils.timestamp()}.zip"

            val savedFile = LocalBackupManager.saveToTodayFolder(
                context = context,
                sourceFile = tempZip,
                fileName = fileName,
                type = BackupFolderType.FULL
            )

            val folderName = BackupPreferences.getBackupFolderName(context)
            val today = TimeUtils.todayFolder()
            val fileSizeKB = savedFile.length() / 1024

            AutoBackupLogStore.addLog("📄 Dosya: $fileName")
            AutoBackupLogStore.addLog("📦 Boyut: $fileSizeKB KB")
            AutoBackupLogStore.addLog("📱 Telefon: /storage/emulated/0/Download/$folderName/full/$today/")

            if (BackupPreferences.isDriveConnected(context)) {
                AutoBackupLogStore.addLog("⏳ Yazma sırası bekleniyor...")
                val lock = DriveLockManager.acquireLock(context)

                if (!lock.acquired) {
                    AutoBackupLogStore.addLog("⚠️ Kilit alınamadı: ${lock.reason}")
                    return Result.retry()
                }

                try {
                    AutoBackupLogStore.addLog("☁️ Drive yükleniyor...")

                    val uploaded = DriveUploadHelper.uploadToDrive(
                        context = context,
                        localFile = savedFile,
                        type = BackupFolderType.FULL
                    )

                    if (uploaded) {
                        AutoBackupLogStore.addLog("✅ Drive yükleme tamam")
                    } else {
                        AutoBackupLogStore.addLog("❌ Drive yükleme başarısız")
                    }
                } finally {
                    DriveLockManager.releaseLock(context)
                    AutoBackupLogStore.addLog("🔓 Kilit bırakıldı")
                }
            }

            LocalBackupManager.deleteOldLocalBackups(context)
            BackupPreferences.setLastBackupTime(context, System.currentTimeMillis())

            AutoBackupLogStore.addLog("✅ OTOMATİK YEDEK TAMAMLANDI (Zaman-$slot)")
            AutoBackupLogStore.addLog("────────────────────────────")

            if (BackupPreferences.isAutoBackupEnabled(context)) {
                AutoBackupScheduler.scheduleAll(
                    context = context,
                    time1 = BackupPreferences.getAutoBackupTime1(context),
                    time2 = BackupPreferences.getAutoBackupTime2(context),
                    time3 = BackupPreferences.getAutoBackupTime3(context)
                )
            }

            Result.success()
        } catch (e: Exception) {
            AutoBackupLogStore.addLog("❌ OTOMATİK YEDEK HATASI: ${e.message ?: "Bilinmeyen hata"}")
            AutoBackupLogStore.addLog("────────────────────────────")

            if (BackupPreferences.isAutoBackupEnabled(context)) {
                AutoBackupScheduler.scheduleAll(
                    context = context,
                    time1 = BackupPreferences.getAutoBackupTime1(context),
                    time2 = BackupPreferences.getAutoBackupTime2(context),
                    time3 = BackupPreferences.getAutoBackupTime3(context)
                )
            }

            Result.failure()
        }
    }
}