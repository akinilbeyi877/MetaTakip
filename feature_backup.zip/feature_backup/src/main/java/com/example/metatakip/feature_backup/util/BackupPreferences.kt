package com.example.metatakip.feature_backup.util

import android.content.Context

object BackupPreferences {

    private const val PREF_NAME = "backup_prefs"
    private const val KEY_DEVICE_ID = "device_id"   // ← BUNU EKLE

    private const val KEY_BACKUP_FOLDER_NAME = "backup_folder_name"
    private const val KEY_BACKUP_FOLDER_URI = "backup_folder_uri"
    private const val KEY_DRIVE_CONNECTED = "drive_connected"
    private const val KEY_DRIVE_EMAIL = "drive_email"
    private const val KEY_AUTO_BACKUP_ENABLED = "auto_backup_enabled"
    private const val KEY_LAST_BACKUP_TIME = "last_backup_time"

    private const val KEY_AUTO_TIME_1 = "auto_time_1"
    private const val KEY_AUTO_TIME_2 = "auto_time_2"
    private const val KEY_AUTO_TIME_3 = "auto_time_3"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun setBackupFolderName(context: Context, folderName: String) {
        prefs(context).edit().putString(KEY_BACKUP_FOLDER_NAME, folderName).apply()
    }

    fun getBackupFolderName(context: Context): String {
        return prefs(context).getString(KEY_BACKUP_FOLDER_NAME, "MetaTakip Yedek")
            ?: "MetaTakip Yedek"
    }

    fun setBackupFolderUri(context: Context, uri: String?) {
        prefs(context).edit().putString(KEY_BACKUP_FOLDER_URI, uri).apply()
    }

    fun getBackupFolderUri(context: Context): String? {
        return prefs(context).getString(KEY_BACKUP_FOLDER_URI, null)
    }

    fun clearBackupFolderUri(context: Context) {
        prefs(context).edit().remove(KEY_BACKUP_FOLDER_URI).apply()
    }

    fun setDriveConnected(context: Context, connected: Boolean) {
        prefs(context).edit().putBoolean(KEY_DRIVE_CONNECTED, connected).apply()
    }

    fun isDriveConnected(context: Context): Boolean {
        return prefs(context).getBoolean(KEY_DRIVE_CONNECTED, false)
    }

    fun setDriveEmail(context: Context, email: String?) {
        prefs(context).edit().putString(KEY_DRIVE_EMAIL, email).apply()
    }

    fun getDriveEmail(context: Context): String? {
        return prefs(context).getString(KEY_DRIVE_EMAIL, null)
    }

    fun setAutoBackupEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_BACKUP_ENABLED, enabled).apply()
    }

    fun isAutoBackupEnabled(context: Context): Boolean {
        return prefs(context).getBoolean(KEY_AUTO_BACKUP_ENABLED, false)
    }

    fun setLastBackupTime(context: Context, timeMillis: Long) {
        prefs(context).edit().putLong(KEY_LAST_BACKUP_TIME, timeMillis).apply()
    }

    fun getLastBackupTime(context: Context): Long {
        return prefs(context).getLong(KEY_LAST_BACKUP_TIME, 0L)
    }

    fun setAutoBackupTime1(context: Context, value: String) {
        prefs(context).edit().putString(KEY_AUTO_TIME_1, value).apply()
    }

    fun getAutoBackupTime1(context: Context): String {
        return prefs(context).getString(KEY_AUTO_TIME_1, "09:00") ?: "09:00"
    }

    fun setAutoBackupTime2(context: Context, value: String) {
        prefs(context).edit().putString(KEY_AUTO_TIME_2, value).apply()
    }

    fun getAutoBackupTime2(context: Context): String {
        return prefs(context).getString(KEY_AUTO_TIME_2, "14:00") ?: "14:00"
    }

    fun setAutoBackupTime3(context: Context, value: String) {
        prefs(context).edit().putString(KEY_AUTO_TIME_3, value).apply()
    }

    fun getAutoBackupTime3(context: Context): String {
        return prefs(context).getString(KEY_AUTO_TIME_3, "21:00") ?: "21:00"
    }

    fun getOrCreateDeviceId(context: Context): String {
        val current = prefs(context).getString(KEY_DEVICE_ID, null)
        if (!current.isNullOrBlank()) return current

        val generated = "device_" + java.util.UUID.randomUUID().toString()
        prefs(context).edit().putString(KEY_DEVICE_ID, generated).apply()
        return generated
    }

}