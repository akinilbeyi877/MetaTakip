package com.example.metatakip.feature_backup.util

import android.content.Context
import java.io.File

object DbFilePaths {
    const val DB_NAME = "MetaTakip.db"

    fun dbFile(context: Context): File = context.getDatabasePath(DB_NAME)
    fun walFile(context: Context): File = File(dbFile(context).absolutePath + "-wal")
    fun shmFile(context: Context): File = File(dbFile(context).absolutePath + "-shm")
}