package com.example.metatakip.feature_backup.data

object TableCatalog {

    val ALL_TABLES = listOf(
        "firma",
        "musteri",
        "siparis",
        "urun",
        "urun_tipi",
        "mesaj_sablon",
        "unvan",
        "personel",
        "etiket_sablon",
        "etiket_sablon_bilesen",
        "etiket_sayfa_ayar",
        "call_logs",
        "delete_log",
        "user"
    )

    val DELETE_ORDER = listOf(
        "urun",
        "siparis",
        "musteri",
        "firma",
        "etiket_sayfa_ayar",
        "etiket_sablon_bilesen",
        "etiket_sablon",
        "call_logs",
        "delete_log",
        "mesaj_sablon",
        "urun_tipi",
        "personel",
        "unvan",
        "user"
    )

    val INSERT_ORDER = listOf(
        "firma",
        "musteri",
        "siparis",
        "urun",
        "urun_tipi",
        "mesaj_sablon",
        "unvan",
        "personel",
        "etiket_sablon",
        "etiket_sablon_bilesen",
        "etiket_sayfa_ayar",
        "call_logs",
        "delete_log",
        "user"
    )

    fun validateRow(table: String, row: Map<String, Any?>, rowIndex: Int): ImportRowResult {
        return when (table) {
            "firma" -> {
                val firmaAdi = row["firmaAdi"] as? String
                if (firmaAdi.isNullOrBlank()) {
                    ImportRowResult(rowIndex, ImportRowResult.Status.ERROR, "firmaAdi boş olamaz")
                } else {
                    ImportRowResult(rowIndex, ImportRowResult.Status.OK, "Uygun")
                }
            }
            "musteri" -> {
                val adSoyad = row["adSoyad"] as? String
                if (adSoyad.isNullOrBlank()) {
                    ImportRowResult(rowIndex, ImportRowResult.Status.ERROR, "adSoyad boş olamaz")
                } else {
                    ImportRowResult(rowIndex, ImportRowResult.Status.OK, "Uygun")
                }
            }
            "urun_tipi" -> {
                val ad = row["ad"] as? String
                if (ad.isNullOrBlank()) {
                    ImportRowResult(rowIndex, ImportRowResult.Status.ERROR, "ad boş olamaz")
                } else {
                    ImportRowResult(rowIndex, ImportRowResult.Status.OK, "Uygun")
                }
            }
            "mesaj_sablon" -> {
                val baslik = row["baslik"] as? String
                if (baslik.isNullOrBlank()) {
                    ImportRowResult(rowIndex, ImportRowResult.Status.ERROR, "baslik boş olamaz")
                } else {
                    ImportRowResult(rowIndex, ImportRowResult.Status.OK, "Uygun")
                }
            }
            "unvan" -> {
                val ad = row["ad"] as? String
                if (ad.isNullOrBlank()) {
                    ImportRowResult(rowIndex, ImportRowResult.Status.ERROR, "ad boş olamaz")
                } else {
                    ImportRowResult(rowIndex, ImportRowResult.Status.OK, "Uygun")
                }
            }
            // Sistem tabloları - validation yapmadan kabul et
            "siparis", "urun", "personel", "etiket_sablon",
            "etiket_sablon_bilesen", "etiket_sayfa_ayar", "call_logs",
            "delete_log", "user" -> {
                ImportRowResult(rowIndex, ImportRowResult.Status.OK, "Uygun")
            }
            else -> {
                ImportRowResult(rowIndex, ImportRowResult.Status.ERROR, "Desteklenmeyen tablo: $table")
            }
        }
    }
}