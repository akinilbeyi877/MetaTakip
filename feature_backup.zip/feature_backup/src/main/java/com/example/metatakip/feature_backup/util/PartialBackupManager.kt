package com.example.metatakip.feature_backup.util

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.util.Log
import com.example.metatakip.feature_backup.data.TableCatalog
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class PartialBackupManager(private val context: Context) {

    companion object {
        private const val TAG = "PartialBackupManager"
    }

    private fun openDbReadWrite(): SQLiteDatabase {
        val dbFile = DbFilePaths.dbFile(context)
        return SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
    }

    fun createPartialZip(selectedTables: List<String>): File {
        val db = openDbReadWrite()

        val tempDir = File(context.cacheDir, "backups").apply { mkdirs() }
        val zipFile = File(tempDir, "temp_partial_${System.currentTimeMillis()}.zip")

        ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zip ->
            val info = JSONObject().apply {
                put("type", "partial")
                put("createdAt", System.currentTimeMillis())
                put("tables", JSONArray(selectedTables))
            }
            zip.putNextEntry(ZipEntry("backup_info.json"))
            zip.write(info.toString(2).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            selectedTables.forEach { table ->
                exportTableAsJson(db, table, zip)
            }
        }

        db.close()
        return zipFile
    }

    fun restoreFromPartialZip(
        zipInput: InputStream,
        selectedTables: List<String>,
        protectUserTable: Boolean = true
    ) {
        val db = openDbReadWrite()
        val tableRowsMap = mutableMapOf<String, JSONArray>()

        ZipInputStream(BufferedInputStream(zipInput)).use { zis ->
            var entry: ZipEntry?
            while (zis.nextEntry.also { entry = it } != null) {
                val name = entry!!.name
                if (name.startsWith("json/") && name.endsWith(".json")) {
                    val text = zis.readBytes().toString(Charsets.UTF_8)
                    val obj = JSONObject(text)
                    val table = obj.getString("table")
                    if (selectedTables.contains(table)) {
                        tableRowsMap[table] = obj.getJSONArray("rows")
                    }
                }
                zis.closeEntry()
            }
        }

        db.beginTransaction()
        try {
            db.execSQL("PRAGMA foreign_keys=OFF")

            val deleteOrder = TableCatalog.DELETE_ORDER
                .filter { selectedTables.contains(it) }
                .filterNot { protectUserTable && it == "user" }

            deleteOrder.forEach { t -> db.execSQL("DELETE FROM $t") }

            val insertOrder = TableCatalog.INSERT_ORDER
                .filter { selectedTables.contains(it) }
                .filterNot { protectUserTable && it == "user" }

            insertOrder.forEach { t ->
                val rows = tableRowsMap[t] ?: JSONArray()
                insertJsonRows(db, t, rows)
            }

            db.execSQL("PRAGMA foreign_keys=ON")
            db.setTransactionSuccessful()
            Log.d(TAG, "✅ Partial restore completed.")
        } finally {
            db.endTransaction()
            db.close()
        }
    }

    private fun exportTableAsJson(db: SQLiteDatabase, table: String, zip: ZipOutputStream) {
        val cursor = db.rawQuery("SELECT * FROM $table", null)
        val jsonArr = cursorToJsonArray(cursor)
        cursor.close()

        val obj = JSONObject().apply {
            put("table", table)
            put("rows", jsonArr)
        }

        zip.putNextEntry(ZipEntry("json/$table.json"))
        zip.write(obj.toString().toByteArray(Charsets.UTF_8))
        zip.closeEntry()

        Log.d(TAG, "✅ JSON exported: $table (${jsonArr.length()} rows)")
    }

    private fun cursorToJsonArray(cursor: Cursor): JSONArray {
        val arr = JSONArray()
        val colCount = cursor.columnCount

        while (cursor.moveToNext()) {
            val o = JSONObject()
            for (i in 0 until colCount) {
                val col = cursor.getColumnName(i)
                when (cursor.getType(i)) {
                    Cursor.FIELD_TYPE_NULL -> o.put(col, JSONObject.NULL)
                    Cursor.FIELD_TYPE_INTEGER -> o.put(col, cursor.getLong(i))
                    Cursor.FIELD_TYPE_FLOAT -> o.put(col, cursor.getDouble(i))
                    Cursor.FIELD_TYPE_STRING -> o.put(col, cursor.getString(i))
                    Cursor.FIELD_TYPE_BLOB -> o.put(col, JSONObject.NULL)
                    else -> o.put(col, cursor.getString(i))
                }
            }
            arr.put(o)
        }
        return arr
    }

    private fun insertJsonRows(db: SQLiteDatabase, table: String, rows: JSONArray) {
        for (i in 0 until rows.length()) {
            val row = rows.getJSONObject(i)
            val keys = row.keys().asSequence().toList()
            if (keys.isEmpty()) continue

            val cols = keys.joinToString(",")
            val qs = keys.joinToString(",") { "?" }
            val sql = "INSERT INTO $table ($cols) VALUES ($qs)"

            val args = keys.map { k ->
                val v = row.opt(k)
                when {
                    v == null || v == JSONObject.NULL -> null
                    v is Number -> v.toString()
                    v is Boolean -> if (v) "1" else "0"
                    else -> v.toString()
                }
            }.toTypedArray()

            db.execSQL(sql, args)
        }
        Log.d(TAG, "✅ Inserted: $table (${rows.length()} rows)")
    }
}