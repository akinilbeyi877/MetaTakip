package com.example.metatakip.feature_backup.util

import android.content.Context
import android.content.Intent
import android.os.Process

object AppRestartUtil {
    fun restartApp(context: Context) {
        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(context.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            ?: return
        context.startActivity(intent)
        Process.killProcess(Process.myPid())
    }
}