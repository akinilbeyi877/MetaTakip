package com.example.metatakip.feature_backup.worker

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow

object AutoBackupLogStore {

    private val _logs = MutableSharedFlow<String>(extraBufferCapacity = 200)
    val logs: SharedFlow<String> = _logs

    fun addLog(message: String) {
        _logs.tryEmit(message)
    }
}