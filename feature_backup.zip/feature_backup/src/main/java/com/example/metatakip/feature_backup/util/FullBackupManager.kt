package com.example.metatakip.feature_backup.util

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Log
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class FullBackupManager(private val context: Context) {

    companion object {
        private const val TAG = "FullBackupManager"
    }

    fun createBackupZip(): File {
        val dbFile = DbFilePaths.dbFile(context)

        try {
            val db = SQLiteDatabase.openDatabase(
                dbFile.absolutePath,
                null,
                SQLiteDatabase.OPEN_READWRITE
            )
            db.execSQL("PRAGMA wal_checkpoint(FULL)")
            db.close()
            Log.d(TAG, "✅ wal_checkpoint(FULL) done")
        } catch (e: Exception) {
            Log.w(TAG, "⚠️ wal_checkpoint failed: ${e.message}")
        }

        val wal = DbFilePaths.walFile(context)
        val shm = DbFilePaths.shmFile(context)

        val tempDir = File(context.cacheDir, "backups").apply { mkdirs() }
        val zipFile = File(tempDir, "temp_full_${System.currentTimeMillis()}.zip")

        ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zip ->
            putEntry(zip, dbFile, DbFilePaths.DB_NAME)
            putEntry(zip, wal, "${DbFilePaths.DB_NAME}-wal")
            putEntry(zip, shm, "${DbFilePaths.DB_NAME}-shm")
        }

        return zipFile
    }

    fun restoreDbFromZip(zipInput: InputStream) {
        val dbFile = DbFilePaths.dbFile(context)
        val wal = DbFilePaths.walFile(context)
        val shm = DbFilePaths.shmFile(context)

        runCatching { wal.delete() }
        runCatching { shm.delete() }

        ZipInputStream(BufferedInputStream(zipInput)).use { zis ->
            var entry: ZipEntry?
            while (zis.nextEntry.also { entry = it } != null) {
                val name = entry!!.name

                val outFile: File? = when (name) {
                    DbFilePaths.DB_NAME -> dbFile
                    "${DbFilePaths.DB_NAME}-wal" -> wal
                    "${DbFilePaths.DB_NAME}-shm" -> shm
                    else -> null
                }

                if (outFile != null) {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { fos ->
                        zis.copyTo(fos)
                    }
                }

                zis.closeEntry()
            }
        }
    }

    private fun putEntry(zip: ZipOutputStream, file: File, entryName: String) {
        if (!file.exists()) return
        zip.putNextEntry(ZipEntry(entryName))
        file.inputStream().use { it.copyTo(zip) }
        zip.closeEntry()
        Log.d(TAG, "✅ Added: $entryName")
    }
}