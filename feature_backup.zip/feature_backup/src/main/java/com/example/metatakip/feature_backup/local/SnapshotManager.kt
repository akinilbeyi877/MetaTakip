package com.example.metatakip.feature_backup.local

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.example.metatakip.feature_backup.util.DbFilePaths
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object SnapshotManager {
    fun createSnapshot(context: Context): File {
        val db = DbFilePaths.dbFile(context)

        if (!db.exists()) {
            throw IllegalStateException("DB bulunamadı: ${db.absolutePath}")
        }

        try {
            val sqliteDb = SQLiteDatabase.openDatabase(
                db.absolutePath,
                null,
                SQLiteDatabase.OPEN_READWRITE
            )
            sqliteDb.execSQL("PRAGMA wal_checkpoint(TRUNCATE)")
            sqliteDb.close()
        } catch (_: Exception) {
        }

        val backupDir = File(context.cacheDir, "snapshots").apply { mkdirs() }
        val zipFile = File(backupDir, "backup_${System.currentTimeMillis()}.zip")

        ZipOutputStream(FileOutputStream(zipFile)).use { zip ->
            addIfExists(zip, db, DbFilePaths.DB_NAME)
            addIfExists(zip, DbFilePaths.walFile(context), "${DbFilePaths.DB_NAME}-wal")
            addIfExists(zip, DbFilePaths.shmFile(context), "${DbFilePaths.DB_NAME}-shm")
        }

        return zipFile
    }

    private fun addIfExists(zip: ZipOutputStream, file: File, entryName: String) {
        if (!file.exists()) return
        zip.putNextEntry(ZipEntry(entryName))
        FileInputStream(file).use { input -> input.copyTo(zip) }
        zip.closeEntry()
    }
}