package com.example.metatakip.feature_backup.worker

import android.content.Context
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

object AutoBackupScheduler {

    fun scheduleAll(context: Context, time1: String, time2: String, time3: String) {
        scheduleSingle(context, 1, time1)
        scheduleSingle(context, 2, time2)
        scheduleSingle(context, 3, time3)
    }

    fun cancelAll(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork("auto_backup_1")
        WorkManager.getInstance(context).cancelUniqueWork("auto_backup_2")
        WorkManager.getInstance(context).cancelUniqueWork("auto_backup_3")
    }

    private fun scheduleSingle(context: Context, slot: Int, hhmm: String) {
        val parts = hhmm.split(":")
        require(parts.size == 2) { "Saat formatı HH:mm olmalı" }

        val hour = parts[0].toInt()
        val minute = parts[1].toInt()

        require(hour in 0..23) { "Saat 0-23 arasında olmalı" }
        require(minute in 0..59) { "Dakika 0-59 arasında olmalı" }

        val now = LocalDateTime.now()
        var nextRun = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)

        if (!nextRun.isAfter(now)) {
            nextRun = nextRun.plusDays(1)
        }

        val delayMillis = Duration.between(now, nextRun).toMillis()

        val inputData = Data.Builder()
            .putInt("slot", slot)
            .build()

        val request = OneTimeWorkRequestBuilder<BackupWorker>()
            .setInputData(inputData)
            .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
            .addTag("auto_backup")
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            "auto_backup_$slot",
            ExistingWorkPolicy.REPLACE,
            request
        )

        AutoBackupLogStore.addLog("🕒 Zaman-$slot kuruldu: $hhmm")
    }
}