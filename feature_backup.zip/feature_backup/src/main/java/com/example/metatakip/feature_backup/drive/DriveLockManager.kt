package com.example.metatakip.feature_backup.drive

import android.content.Context
import com.example.metatakip.feature_backup.util.BackupPreferences
import com.google.api.client.http.ByteArrayContent
import com.google.api.services.drive.model.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject

object DriveLockManager {

    private const val SYSTEM_FOLDER_NAME = "system"
    private const val LOCK_FILE_NAME = "lock.json"
    private const val STALE_LOCK_MS = 2 * 60 * 1000L
    private const val DEFAULT_WAIT_MS = 30 * 1000L
    private const val POLL_INTERVAL_MS = 1500L

    data class LockState(
        val status: String,
        val owner: String,
        val timestamp: Long,
        val displayTime: String,
        val fileId: String?
    ) {
        val isBusy: Boolean get() = status.equals("busy", ignoreCase = true)
        val isFree: Boolean get() = !isBusy
    }

    data class AcquireResult(
        val acquired: Boolean,
        val reason: String,
        val state: LockState? = null
    )

    suspend fun acquireLock(
        context: Context,
        waitTimeoutMs: Long = DEFAULT_WAIT_MS,
        onStatus: (suspend (String) -> Unit)? = null
    ): AcquireResult {
        return withContext(Dispatchers.IO) {
            val driveService = DriveBackupManager.getDriveService(context)
                ?: return@withContext AcquireResult(false, "Drive servisi başlatılamadı")

            val owner = BackupPreferences.getOrCreateDeviceId(context)
            val startedAt = System.currentTimeMillis()

            while (true) {
                val rootId = ensureRootFolderId(context)
                    ?: return@withContext AcquireResult(false, "Kök klasör bulunamadı")

                val systemId = findOrCreateFolder(driveService, SYSTEM_FOLDER_NAME, rootId)
                val current = getOrCreateLockState(driveService, systemId)

                val now = System.currentTimeMillis()
                val stale = current.isBusy && (now - current.timestamp) > STALE_LOCK_MS

                if (current.isFree || stale || current.owner == owner) {
                    val payload = lockJson(status = "busy", owner = owner, timestamp = now)
                    val fileId = upsertLockFile(driveService, systemId, current.fileId, payload)

                    return@withContext AcquireResult(
                        acquired = true,
                        reason = if (stale) "Eski kilit temizlendi" else "Kilit alındı",
                        state = LockState("busy", owner, now, now.toString(), fileId)
                    )
                }

                val elapsed = now - startedAt
                if (elapsed >= waitTimeoutMs) {
                    return@withContext AcquireResult(
                        acquired = false,
                        reason = "Başka cihaz işlem yapıyor",
                        state = current
                    )
                }

                onStatus?.invoke("Başka cihaz işlem yapıyor, bekleniyor...")
                delay(POLL_INTERVAL_MS)
            }

            @Suppress("UNREACHABLE_CODE")
            AcquireResult(false, "Bilinmeyen durum")
        }
    }

    suspend fun releaseLock(context: Context): Boolean = withContext(Dispatchers.IO) {
        val driveService = DriveBackupManager.getDriveService(context) ?: return@withContext false
        val rootId = ensureRootFolderId(context) ?: return@withContext false
        val systemId = findOrCreateFolder(driveService, SYSTEM_FOLDER_NAME, rootId)
        val current = getOrCreateLockState(driveService, systemId)
        val owner = BackupPreferences.getOrCreateDeviceId(context)

        if (current.fileId == null) return@withContext false
        if (current.owner.isNotBlank() && current.owner != owner) return@withContext false

        val payload = lockJson(status = "free", owner = "", timestamp = System.currentTimeMillis())
        upsertLockFile(driveService, systemId, current.fileId, payload)
        true
    }

    suspend fun getLockState(context: Context): LockState? = withContext(Dispatchers.IO) {
        val driveService = DriveBackupManager.getDriveService(context) ?: return@withContext null
        val rootId = ensureRootFolderId(context) ?: return@withContext null
        val systemId = findOrCreateFolder(driveService, SYSTEM_FOLDER_NAME, rootId)
        getOrCreateLockState(driveService, systemId)
    }

    private fun ensureRootFolderId(context: Context): String? {
        val driveService = DriveBackupManager.getDriveService(context) ?: return null
        val rootFolderName = BackupPreferences.getBackupFolderName(context)
        return findOrCreateFolder(driveService, rootFolderName, null)
    }

    private fun getOrCreateLockState(
        driveService: com.google.api.services.drive.Drive,
        systemFolderId: String
    ): LockState {
        val existing = findFile(driveService, LOCK_FILE_NAME, systemFolderId)
        if (existing == null) {
            val payload = lockJson(status = "free", owner = "", timestamp = 0L)
            val fileId = upsertLockFile(driveService, systemFolderId, null, payload)
            return LockState("free", "", 0L, "0", fileId)
        }

        val bytes = driveService.files().get(existing.id).executeMediaAsInputStream().use { it.readBytes() }
        val text = bytes.toString(Charsets.UTF_8)
        val json = runCatching { JSONObject(text) }.getOrElse { JSONObject() }

        return LockState(
            status = json.optString("status", "free"),
            owner = json.optString("owner", ""),
            timestamp = json.optLong("timestamp", 0L),
            displayTime = json.optString("time", ""),
            fileId = existing.id
        )
    }

    private fun upsertLockFile(
        driveService: com.google.api.services.drive.Drive,
        systemFolderId: String,
        fileId: String?,
        payload: String
    ): String {
        val media = ByteArrayContent("application/json", payload.toByteArray(Charsets.UTF_8))

        return if (fileId == null) {
            val meta = File().apply {
                name = LOCK_FILE_NAME
                parents = listOf(systemFolderId)
                mimeType = "application/json"
            }
            driveService.files()
                .create(meta, media)
                .setFields("id")
                .execute()
                .id
        } else {
            driveService.files()
                .update(fileId, null, media)
                .setFields("id")
                .execute()
                .id
        }
    }

    private fun lockJson(status: String, owner: String, timestamp: Long): String {
        return JSONObject()
            .put("status", status)
            .put("owner", owner)
            .put("timestamp", timestamp)
            .put("time", timestamp.toString())
            .toString()
    }

    private fun findOrCreateFolder(
        driveService: com.google.api.services.drive.Drive,
        folderName: String,
        parentId: String?
    ): String {
        val existing = findFolder(driveService, folderName, parentId)
        if (existing != null) return existing.id

        val folderMeta = File().apply {
            name = folderName
            mimeType = "application/vnd.google-apps.folder"
            if (parentId != null) parents = listOf(parentId)
        }

        return driveService.files()
            .create(folderMeta)
            .setFields("id")
            .execute()
            .id
    }

    private fun findFolder(
        driveService: com.google.api.services.drive.Drive,
        folderName: String,
        parentId: String?
    ): File? {
        val escaped = folderName.replace("'", "\\'")
        val parentClause = if (parentId != null) " and '$parentId' in parents" else ""
        val query = "mimeType = 'application/vnd.google-apps.folder' and trashed = false and name = '$escaped'$parentClause"

        return driveService.files()
            .list()
            .setQ(query)
            .setSpaces("drive")
            .setFields("files(id,name)")
            .execute()
            .files
            ?.firstOrNull()
    }

    private fun findFile(
        driveService: com.google.api.services.drive.Drive,
        fileName: String,
        parentId: String
    ): File? {
        val escaped = fileName.replace("'", "\\'")
        val query = "trashed = false and name = '$escaped' and '$parentId' in parents"

        return driveService.files()
            .list()
            .setQ(query)
            .setSpaces("drive")
            .setFields("files(id,name)")
            .execute()
            .files
            ?.firstOrNull()
    }
}
