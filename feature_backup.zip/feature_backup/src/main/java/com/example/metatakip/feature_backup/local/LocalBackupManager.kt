package com.example.metatakip.feature_backup.local

import android.content.Context
import android.os.Environment
import com.example.metatakip.feature_backup.util.BackupFolderType
import com.example.metatakip.feature_backup.util.BackupPreferences
import com.example.metatakip.feature_backup.util.TimeUtils
import java.io.File

object LocalBackupManager {

    private fun ensureDir(dir: File): File {
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun getRootFolder(context: Context): File {
        val rootName = BackupPreferences.getBackupFolderName(context)
        val downloads =
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        return ensureDir(File(downloads, rootName))
    }

    fun getTypeFolder(context: Context, type: BackupFolderType): File {
        return ensureDir(File(getRootFolder(context), type.folderName))
    }

    fun getTodayFolder(context: Context, type: BackupFolderType): File {
        val today = TimeUtils.todayFolder()
        return ensureDir(File(getTypeFolder(context, type), today))
    }

    fun saveToTodayFolder(
        context: Context,
        sourceFile: File,
        fileName: String,
        type: BackupFolderType
    ): File {
        val targetDir = getTodayFolder(context, type)
        val targetFile = File(targetDir, fileName)

        sourceFile.copyTo(targetFile, overwrite = true)

        if (sourceFile.exists() && sourceFile.absolutePath != targetFile.absolutePath) {
            sourceFile.delete()
        }

        return targetFile
    }

    /**
     * Eski çağrılar bozulmasın diye bırakıldı.
     * Type verilmezse FULL kabul edilir.
     */
    fun saveToTodayFolder(
        context: Context,
        sourceFile: File,
        fileName: String
    ): File {
        return saveToTodayFolder(
            context = context,
            sourceFile = sourceFile,
            fileName = fileName,
            type = BackupFolderType.FULL
        )
    }

    fun createTodaySubFolder(
        context: Context,
        type: BackupFolderType,
        subFolderName: String
    ): File {
        return ensureDir(File(getTodayFolder(context, type), subFolderName))
    }

    /**
     * Eski kullanım bozulmasın diye FULL altında bırakılır.
     */
    fun createTodaySubFolder(
        context: Context,
        subFolderName: String
    ): File {
        return createTodaySubFolder(
            context = context,
            type = BackupFolderType.FULL,
            subFolderName = subFolderName
        )
    }

    fun deleteOldLocalBackups(context: Context, keepCount: Int = 20) {
        val root = getRootFolder(context)
        if (!root.exists()) return

        val allFiles = root.walkTopDown()
            .filter { it.isFile && (it.extension.equals("zip", true) || it.extension.equals("csv", true)) }
            .sortedByDescending { it.lastModified() }
            .toList()

        allFiles.drop(keepCount).forEach { file ->
            runCatching { file.delete() }
        }
    }
}