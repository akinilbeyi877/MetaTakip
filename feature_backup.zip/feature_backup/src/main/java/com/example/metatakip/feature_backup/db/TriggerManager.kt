package com.example.metatakip.feature_backup.db

import android.database.sqlite.SQLiteDatabase
import android.util.Log

object TriggerManager {
    private const val TAG = "TriggerManager"

    /**
     * Tüm tablolar için trigger'ları oluştur
     */
    fun createAllTriggers(db: SQLiteDatabase) {
        // Önce eski trigger'ları temizle (opsiyonel)
        // dropAllTriggers(db)

        // MÜŞTERİ tablosu trigger'ları
        createMusteriTriggers(db)

        // SİPARİŞ tablosu trigger'ları
        createSiparisTriggers(db)

        // FİRMA tablosu trigger'ları
        createFirmaTriggers(db)

        // ÜRÜN tablosu trigger'ları
        createUrunTriggers(db)

        // ÜRÜN TİPİ tablosu trigger'ları
        createUrunTipiTriggers(db)

        // PERSONEL tablosu trigger'ları
        createPersonelTriggers(db)

        // MESAJ ŞABLON tablosu trigger'ları
        createMesajSablonTriggers(db)

        // ÜNVAN tablosu trigger'ları
        createUnvanTriggers(db)

        // ETİKET ŞABLON tablosu trigger'ları
        createEtiketSablonTriggers(db)

        // ETİKET ŞABLON BİLEŞEN tablosu trigger'ları
        createEtiketSablonBilesenTriggers(db)

        // ETİKET SAYFA AYAR tablosu trigger'ları
        createEtiketSayfaAyarTriggers(db)

        // CALL_LOGS tablosu trigger'ları
        createCallLogsTriggers(db)

        // DELETE_LOG tablosu trigger'ları
        createDeleteLogTriggers(db)

        // USER tablosu trigger'ları (opsiyonel - korumalı)
        // createUserTriggers(db)

        Log.d(TAG, "✅ Tüm trigger'lar oluşturuldu")
    }

    /**
     * MÜŞTERİ tablosu trigger'ları
     */
    private fun createMusteriTriggers(db: SQLiteDatabase) {
        // INSERT trigger
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_musteri_insert 
            AFTER INSERT ON musteri
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at, details)
                VALUES (
                    'musteri', 
                    'INSERT', 
                    NEW.id, 
                    strftime('%s','now'),
                    'Yeni müşteri: ' || NEW.adSoyad
                );
            END;
        """)

        // UPDATE trigger
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_musteri_update 
            AFTER UPDATE ON musteri
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at, details)
                VALUES (
                    'musteri', 
                    'UPDATE', 
                    NEW.id, 
                    strftime('%s','now'),
                    'Müşteri güncellendi: ' || NEW.adSoyad
                );
            END;
        """)

        // DELETE trigger
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_musteri_delete 
            AFTER DELETE ON musteri
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at, details)
                VALUES (
                    'musteri', 
                    'DELETE', 
                    OLD.id, 
                    strftime('%s','now'),
                    'Müşteri silindi: ' || OLD.adSoyad
                );
            END;
        """)

        Log.d(TAG, "✅ musteri trigger'ları oluşturuldu")
    }

    /**
     * SİPARİŞ tablosu trigger'ları
     */
    private fun createSiparisTriggers(db: SQLiteDatabase) {
        // INSERT trigger
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_siparis_insert 
            AFTER INSERT ON siparis
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('siparis', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        // UPDATE trigger
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_siparis_update 
            AFTER UPDATE ON siparis
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('siparis', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        // DELETE trigger
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_siparis_delete 
            AFTER DELETE ON siparis
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('siparis', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ siparis trigger'ları oluşturuldu")
    }

    /**
     * FİRMA tablosu trigger'ları
     */
    private fun createFirmaTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_firma_insert 
            AFTER INSERT ON firma
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('firma', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_firma_update 
            AFTER UPDATE ON firma
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('firma', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_firma_delete 
            AFTER DELETE ON firma
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('firma', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ firma trigger'ları oluşturuldu")
    }

    /**
     * ÜRÜN tablosu trigger'ları
     */
    private fun createUrunTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_urun_insert 
            AFTER INSERT ON urun
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('urun', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_urun_update 
            AFTER UPDATE ON urun
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('urun', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_urun_delete 
            AFTER DELETE ON urun
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('urun', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ urun trigger'ları oluşturuldu")
    }

    /**
     * ÜRÜN TİPİ tablosu trigger'ları
     */
    private fun createUrunTipiTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_urun_tipi_insert 
            AFTER INSERT ON urun_tipi
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('urun_tipi', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_urun_tipi_update 
            AFTER UPDATE ON urun_tipi
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('urun_tipi', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_urun_tipi_delete 
            AFTER DELETE ON urun_tipi
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('urun_tipi', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ urun_tipi trigger'ları oluşturuldu")
    }

    /**
     * PERSONEL tablosu trigger'ları
     */
    private fun createPersonelTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_personel_insert 
            AFTER INSERT ON personel
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('personel', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_personel_update 
            AFTER UPDATE ON personel
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('personel', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_personel_delete 
            AFTER DELETE ON personel
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('personel', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ personel trigger'ları oluşturuldu")
    }

    /**
     * MESAJ ŞABLON tablosu trigger'ları
     */
    private fun createMesajSablonTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_mesaj_sablon_insert 
            AFTER INSERT ON mesaj_sablon
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('mesaj_sablon', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_mesaj_sablon_update 
            AFTER UPDATE ON mesaj_sablon
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('mesaj_sablon', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_mesaj_sablon_delete 
            AFTER DELETE ON mesaj_sablon
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('mesaj_sablon', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ mesaj_sablon trigger'ları oluşturuldu")
    }

    /**
     * ÜNVAN tablosu trigger'ları
     */
    private fun createUnvanTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_unvan_insert 
            AFTER INSERT ON unvan
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('unvan', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_unvan_update 
            AFTER UPDATE ON unvan
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('unvan', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_unvan_delete 
            AFTER DELETE ON unvan
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('unvan', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ unvan trigger'ları oluşturuldu")
    }

    /**
     * ETİKET ŞABLON tablosu trigger'ları
     */
    private fun createEtiketSablonTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_etiket_sablon_insert 
            AFTER INSERT ON etiket_sablon
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('etiket_sablon', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_etiket_sablon_update 
            AFTER UPDATE ON etiket_sablon
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('etiket_sablon', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_etiket_sablon_delete 
            AFTER DELETE ON etiket_sablon
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('etiket_sablon', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ etiket_sablon trigger'ları oluşturuldu")
    }

    /**
     * ETİKET ŞABLON BİLEŞEN tablosu trigger'ları
     */
    private fun createEtiketSablonBilesenTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_etiket_sablon_bilesen_insert 
            AFTER INSERT ON etiket_sablon_bilesen
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('etiket_sablon_bilesen', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_etiket_sablon_bilesen_update 
            AFTER UPDATE ON etiket_sablon_bilesen
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('etiket_sablon_bilesen', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_etiket_sablon_bilesen_delete 
            AFTER DELETE ON etiket_sablon_bilesen
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('etiket_sablon_bilesen', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ etiket_sablon_bilesen trigger'ları oluşturuldu")
    }

    /**
     * ETİKET SAYFA AYAR tablosu trigger'ları
     */
    private fun createEtiketSayfaAyarTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_etiket_sayfa_ayar_insert 
            AFTER INSERT ON etiket_sayfa_ayar
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('etiket_sayfa_ayar', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_etiket_sayfa_ayar_update 
            AFTER UPDATE ON etiket_sayfa_ayar
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('etiket_sayfa_ayar', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_etiket_sayfa_ayar_delete 
            AFTER DELETE ON etiket_sayfa_ayar
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('etiket_sayfa_ayar', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ etiket_sayfa_ayar trigger'ları oluşturuldu")
    }

    /**
     * CALL_LOGS tablosu trigger'ları
     */
    private fun createCallLogsTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_call_logs_insert 
            AFTER INSERT ON call_logs
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('call_logs', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_call_logs_update 
            AFTER UPDATE ON call_logs
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('call_logs', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_call_logs_delete 
            AFTER DELETE ON call_logs
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('call_logs', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ call_logs trigger'ları oluşturuldu")
    }

    /**
     * DELETE_LOG tablosu trigger'ları
     */
    private fun createDeleteLogTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_delete_log_insert 
            AFTER INSERT ON delete_log
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('delete_log', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_delete_log_update 
            AFTER UPDATE ON delete_log
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('delete_log', 'UPDATE', NEW.id, strftime('%s','now'));
            END;
        """)

        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_delete_log_delete 
            AFTER DELETE ON delete_log
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('delete_log', 'DELETE', OLD.id, strftime('%s','now'));
            END;
        """)

        Log.d(TAG, "✅ delete_log trigger'ları oluşturuldu")
    }

    /**
     * USER tablosu trigger'ları (opsiyonel - korumalı)
     */
    /*
    private fun createUserTriggers(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TRIGGER IF NOT EXISTS trigger_user_insert
            AFTER INSERT ON user
            BEGIN
                INSERT INTO change_log (table_name, action_type, record_id, changed_at)
                VALUES ('user', 'INSERT', NEW.id, strftime('%s','now'));
            END;
        """)
        // ... update ve delete trigger'ları
    }
    */

    /**
     * Tüm trigger'ları temizle (opsiyonel)
     */
    fun dropAllTriggers(db: SQLiteDatabase) {
        val tables = listOf(
            "musteri", "siparis", "firma", "urun", "urun_tipi",
            "personel", "mesaj_sablon", "unvan", "etiket_sablon",
            "etiket_sablon_bilesen", "etiket_sayfa_ayar", "call_logs", "delete_log"
        )

        tables.forEach { table ->
            db.execSQL("DROP TRIGGER IF EXISTS trigger_${table}_insert")
            db.execSQL("DROP TRIGGER IF EXISTS trigger_${table}_update")
            db.execSQL("DROP TRIGGER IF EXISTS trigger_${table}_delete")
        }

        Log.d(TAG, "🗑️ Tüm trigger'lar temizlendi")
    }
}