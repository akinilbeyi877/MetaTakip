package com.example.metatakip.feature_backup.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.example.metatakip.feature_backup.util.DbFilePaths

object MigrationHelper {

    /**
     * Veritabanı sürümünü kontrol eder ve gerekli migration'ları yapar
     */
    fun checkAndMigrate(context: Context) {
        val dbFile = DbFilePaths.dbFile(context)
        val db = SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)

        try {
            // change_log tablosu var mı kontrol et
            if (!isTableExists(db, "change_log")) {
                createChangeLogTable(db)
                createAllTriggers(db)
            } else {
                // Tablo varsa yapısal güncelleme gerekli mi kontrol et
                upgradeChangeLogTableIfNeeded(db)
            }
        } finally {
            db.close()
        }
    }

    /**
     * Tablo var mı kontrol et
     */
    private fun isTableExists(db: SQLiteDatabase, tableName: String): Boolean {
        val cursor = db.rawQuery(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            arrayOf(tableName)
        )
        val exists = cursor.moveToFirst()
        cursor.close()
        return exists
    }

    /**
     * change_log tablosunu oluştur
     */
    private fun createChangeLogTable(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS change_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                table_name TEXT NOT NULL,
                action_type TEXT NOT NULL,
                record_id INTEGER,
                changed_at INTEGER NOT NULL,
                user_id INTEGER DEFAULT 0,
                details TEXT,
                synced INTEGER DEFAULT 0
            )
        """)

        // İndeks ekle (performans için)
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_change_log_changed_at ON change_log(changed_at)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_change_log_synced ON change_log(synced)")

        android.util.Log.d("MigrationHelper", "✅ change_log tablosu oluşturuldu")
    }

    /**
     * Tablo yapısını güncelle (ileride sütun eklemek gerekirse)
     */
    private fun upgradeChangeLogTableIfNeeded(db: SQLiteDatabase) {
        // Örnek: İleride yeni bir sütun eklemek gerekirse
        // if (!isColumnExists(db, "change_log", "new_column")) {
        //     db.execSQL("ALTER TABLE change_log ADD COLUMN new_column TEXT DEFAULT ''")
        // }
    }

    /**
     * Kolon var mı kontrol et
     */
    private fun isColumnExists(db: SQLiteDatabase, tableName: String, columnName: String): Boolean {
        val cursor = db.rawQuery("PRAGMA table_info($tableName)", null)
        var exists = false
        while (cursor.moveToNext()) {
            if (cursor.getString(1) == columnName) {
                exists = true
                break
            }
        }
        cursor.close()
        return exists
    }

    /**
     * Tüm trigger'ları oluştur (TriggerManager'a yönlendir)
     */
    private fun createAllTriggers(db: SQLiteDatabase) {
        TriggerManager.createAllTriggers(db)
    }
}