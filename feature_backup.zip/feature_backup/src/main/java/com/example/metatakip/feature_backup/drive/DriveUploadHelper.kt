package com.example.metatakip.feature_backup.drive

import android.content.Context
import com.example.metatakip.feature_backup.util.BackupFolderType
import com.example.metatakip.feature_backup.util.BackupPreferences
import com.example.metatakip.feature_backup.util.TimeUtils
import com.google.api.client.http.FileContent
import com.google.api.services.drive.Drive
import com.google.api.services.drive.model.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File as LocalFile

object DriveUploadHelper {

    suspend fun uploadToDrive(
        context: Context,
        localFile: LocalFile,
        type: BackupFolderType
    ): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val driveService = DriveBackupManager.getDriveService(context) ?: return@withContext false

            val rootFolderName = BackupPreferences.getBackupFolderName(context)
            val today = TimeUtils.todayFolder()

            val rootId = findOrCreateFolder(
                driveService = driveService,
                folderName = rootFolderName,
                parentId = null
            )

            val typeId = findOrCreateFolder(
                driveService = driveService,
                folderName = type.folderName,
                parentId = rootId
            )

            val todayId = findOrCreateFolder(
                driveService = driveService,
                folderName = today,
                parentId = typeId
            )

            val meta = File().apply {
                name = localFile.name
                parents = listOf(todayId)
            }

            val mimeType = when (localFile.extension.lowercase()) {
                "zip" -> "application/zip"
                "csv" -> "text/csv"
                else -> "application/octet-stream"
            }

            val media = FileContent(mimeType, localFile)

            driveService.files()
                .create(meta, media)
                .setFields("id,name,parents")
                .execute()

            true
        }.getOrElse {
            false
        }
    }

    /**
     * Eski çağrılar bozulmasın diye FULL varsayılan bırakıldı.
     */
    suspend fun uploadToDrive(
        context: Context,
        localFile: LocalFile
    ): Boolean {
        return uploadToDrive(
            context = context,
            localFile = localFile,
            type = BackupFolderType.FULL
        )
    }

    private fun findOrCreateFolder(
        driveService: Drive,
        folderName: String,
        parentId: String?
    ): String {
        val escaped = folderName.replace("'", "\\'")
        val parentClause = if (parentId != null) " and '$parentId' in parents" else ""
        val query =
            "mimeType = 'application/vnd.google-apps.folder' and trashed = false and name = '$escaped'$parentClause"

        val existing = driveService.files()
            .list()
            .setQ(query)
            .setSpaces("drive")
            .setFields("files(id,name)")
            .execute()
            .files
            ?.firstOrNull()

        if (existing != null) return existing.id

        val folderMeta = File().apply {
            name = folderName
            mimeType = "application/vnd.google-apps.folder"
            if (parentId != null) {
                parents = listOf(parentId)
            }
        }

        return driveService.files()
            .create(folderMeta)
            .setFields("id")
            .execute()
            .id
    }
}