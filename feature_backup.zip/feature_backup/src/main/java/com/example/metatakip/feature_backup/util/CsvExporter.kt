package com.example.metatakip.feature_backup.util

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import java.io.*

object CsvExporter {
    fun exportTable(db: SQLiteDatabase, table: String, out: OutputStream) {
        val cursor = db.rawQuery("SELECT * FROM $table", null)
        OutputStreamWriter(out, Charsets.UTF_8).use { w ->
            writeCursorAsCsv(cursor, w)
        }
        cursor.close()
    }

    fun exportTableToFile(db: SQLiteDatabase, table: String, file: File) {
        FileOutputStream(file).use { out ->
            exportTable(db, table, out)
        }
    }

    fun writeCursorAsCsv(cursor: Cursor, w: Writer) {
        val colCount = cursor.columnCount
        // Header (tüm kolonlar - ID dahil!)
        w.append((0 until colCount).joinToString(",") { cursor.getColumnName(it) })
        w.append("\n")

        // Data
        while (cursor.moveToNext()) {
            val row = (0 until colCount).joinToString(",") { i ->
                val v = cursor.getString(i) ?: ""
                // CSV formatı: tırnak içine al ve tırnakları çift tırnak yap
                "\"${v.replace("\"", "\"\"")}\""
            }
            w.append(row)
            w.append("\n")
        }
        w.flush()
    }
}